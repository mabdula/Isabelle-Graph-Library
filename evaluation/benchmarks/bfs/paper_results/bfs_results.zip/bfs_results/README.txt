BFS study -- the published tables and raw rows (Tables 9 to 12)
===============================================================

One directory per column, one CSV per family:

    <column>/Square-n.csv, Long-n.csv, Dense-n.csv, USA-road-t.csv
    <column>/conditions.txt    machine, pinning, clock and cap, as the campaign
                               that measured the column recorded them
    <column>/raw/<family>.csv  the driver rows the tables were built from, one
                               time per run (plus inferred_from and core,
                               appended by the campaign runner)
    COLUMNS.txt                which column comes from which results directory

CSV SHAPE

    nodes,s1,...,s10,finished,average_ms              the three generated families
    nodes,instance,q1,...,q10,finished,average_ms     the road networks

  One row per problem size.  The generated families put ten instances at each
  size and ask one question of each (s1..s10); the road family has one network
  per size and asks ten questions of it (q1..q10).  Each cell is the median of
  that problem's three repeats, in milliseconds; finished says how many of the
  ten produced a time; average_ms is the mean over those.

  A cell that is not a number: TIMEOUT (the 1200 s cap) or MEMORY (out of
  address space, heap or stack; a run killed by the kernel's out-of-memory
  killer is ERROR in the raw rows and MEMORY here).  Where a smaller size of
  the same family already failed, the larger sizes were not run and carry the
  same word.  A failed run's time is never averaged in.

  sml_csr on the NY road network (264346 nodes) comes from
  rerun_ny_20261012_101143: the same driver, pairs and cap, measured one
  problem at a time with nothing else on the machine.

THE CLOCK

  Every time is the difference between two readings of the CPU clock (user +
  system): the first immediately before the clocked period opens (after the
  input has been parsed, and for the JVM solvers after the warm-up), the second
  immediately on return.

  The six exports: the whole verified program, structure build included (the
  functional exports' cons list of arcs is marshalling, built outside and
  recorded in the campaign directory).

  The libraries: a structure that can be filled arc by arc while the file is
  read may be built outside the clock; one that needs the complete arc list
  is built after parsing, inside the clock, as the first part of the clocked
  period.  Three libraries are measured both ways:

    lemon_csr      LEMON's StaticDigraph (CSR), built by build() from the
                   tail-sorted arc list.  INSIDE, rebuilt on every repeat: the
                   clock covers the counting sort by tail, build(), Bfs's own
                   setup and the search.
    lemon_linked   LEMON's SmartDigraph, a linked arc list filled arc by arc
                   as the file is read.  OUTSIDE: the clock covers Bfs's setup
                   and the search.
    jgrapht_csr    jgrapht-opt's SparseIntDirectedGraph, a CSR boolean matrix
                   from the complete arc list (NO_INCOMING_EDGES).  INSIDE,
                   rebuilt on every repeat.
    jgrapht_hashgraph
                   jgrapht-core's DirectedPseudograph (an object per arc, hash
                   maps around it), filled as the file is read.  OUTSIDE: the
                   clock covers the iterator alone.
    scipy_csr      SciPy's csr_matrix from coo_matrix(...).tocsr().  INSIDE,
                   rebuilt on every repeat.
    scipy_prebuilt the same matrix, built once before the clock opened; the
                   clock covers breadth_first_order alone.  OUTSIDE.
    networkx       NetworkX's DiGraph, a dict of dicts, filled as the file is
                   read.  OUTSIDE.

  The raw rows of lemon_csr, jgrapht_csr and scipy_csr carry clock_build_ms
  and clock_solve_ms: the two parts of the one clocked period, from one
  intermediate reading after the structure is built; they add up to cpu_ms.
  Repacking the parsed arrays into a library's input list is marshalling in
  every column and stays outside.

  JGraphT: jgrapht_csr is on the solver thread's CPU clock plus the
  collector's pause time (GarbageCollectorMXBeans), warmed up on the instance
  itself (an instance over 2^18 arcs on its induced subgraph); jgrapht_hashgraph
  is on the bare thread clock after a warm-up on a synthetic graph.  The two
  Scala columns are on the bare thread clock as well and understate their
  collector work (median gap to the whole-process clock 2.0x for scala_csr and
  1.1x for scala_rbt, part of which is the JIT): read them as lower bounds.

  No parallel arcs were collapsed: the graphs are unweighted and parallel arcs
  change no breadth-first answer.  No solver exits early: every column is a
  full breadth-first sweep from the source (LEMON Bfs::run(s), the JGraphT
  iterator drained with cross-component traversal off, breadth_first_order and
  bfs_predecessors have no target); the target only decides which answer is
  read off at the end.  Every edge weight is ignored.

ONE PROBLEM PER PROCESS

  A problem is a graph and a pair; each problem and each repeat was its own
  process, pinned one run per L3 cache island with cores 0-3 kept free of
  measurement work.  The solvers were measured in groups, a group finishing
  every family, size and repeat before the next began.

THE GRID

  Square-n     n = 1024 .. 2096704, twelve sizes, ten instances each
  Long-n       n = 1024 .. 2097152, twelve sizes, ten instances each
  Dense-n      n = 1024 .. 32768, six sizes, ten instances each
               (m = n^2/16, the challenge's own sprand generator)
  USA-road-t   twelve road networks, NY (264346 nodes) .. USA (23947347),
               ten source-target pairs each
  three repeats of every problem.  The pairs were drawn once from a recorded
  seed and are the same for every solver (the Dijkstra study's draw on the
  shared families); each pair is copied into the raw row beside its time.

THE THIRTEEN COLUMNS

  ours: two code exports of the same verified algorithm, imperative over
  arrays (_csr) and functional over red-black trees (_rbt), each compiled to
  three languages:
    sml_csr, sml_rbt      Standard ML, MLton 20241230 -inline 10000
    scala_csr, scala_rbt  Scala 3.3.8 on JDK 21.0.12, serial GC, -Xmx45g, bare thread clock
    go_csr, go_rbt        Go 1.27.2, goroutine stack raised to the runtime maximum
                          (a stack overflow is MEMORY)
  libraries:
    lemon_csr         LEMON 1.3.1 Bfs<StaticDigraph>, CSR built INSIDE the clock; g++ 11.4.0 -O3 -march=native -DNDEBUG
    lemon_linked      LEMON 1.3.1 Bfs<SmartDigraph>, linked arc list built OUTSIDE; g++ 11.4.0 -O2 -DNDEBUG
    jgrapht_csr       JGraphT 1.5.3 BreadthFirstIterator on SparseIntDirectedGraph (jgrapht-opt), built INSIDE; JDK 21.0.12, serial GC, -Xmx45g; thread CPU + collector time
    jgrapht_hashgraph JGraphT 1.5.3 BreadthFirstIterator on DirectedPseudograph, built OUTSIDE; bare thread CPU clock
    scipy_csr         scipy 1.15.3 sparse.csgraph.breadth_first_order on a CSR matrix built INSIDE
    scipy_prebuilt    the same call on the matrix built BEFORE the clock opened
    networkx          networkx 3.4.2 bfs_predecessors on a DiGraph filled while the file is read

WHERE THE ROWS COME FROM

    results/20261011_131341          sml_csr, sml_rbt, scala_csr, scala_rbt, go_csr, go_rbt,
                                     lemon_linked, jgrapht_hashgraph, scipy_prebuilt, networkx
    results/20261014_161905          lemon_csr, jgrapht_csr, scipy_csr
    results/rerun_ny_20261012_101143 sml_csr on USA-road-t at 264346 nodes
