BFS study -- headline timings
==================================

Thirteen columns on four breadth-first-search families: two grid families of
the 9th DIMACS Implementation Challenge on shortest paths, its USA road
networks, and a dense family built for this study with the challenge's own
generator.  Ten solvers -- six builds of two verified Isabelle exports and
four libraries -- of which three libraries appear twice, once on the
structure the first campaign gave them and once on CSR built inside the
clock.  One directory per column, one CSV per family:

    <column>/Square-n.csv
    <column>/Long-n.csv
    <column>/Dense-n.csv
    <column>/USA-road-t.csv
    <column>/conditions.txt    machine, pinning, clock and cap, exactly as
                               the campaign that measured that column
                               recorded them
    <column>/raw/              the unaggregated driver rows these tables
                               were built from
    COLUMNS.txt                which column comes from which directory

CSV SHAPE

    nodes,s1,...,s10,finished,average_ms              the three generated families
    nodes,instance,q1,...,q10,finished,average_ms     the road networks

  One row per problem size.  The three generated families put TEN INSTANCES at
  each size and ask one question of each, so s1..s10 are the ten instances.
  The road family has one real network per size and asks TEN QUESTIONS of it,
  so q1..q10 are the ten source-target pairs and the network's name sits beside
  its node count.  Either way a column is one search problem.

  finished says how many of the ten produced a time.  average_ms, the last
  column, is the average over those.

  Each cell is the MEDIAN of that problem's three repeats, in milliseconds.
  Median within a problem, mean across problems: the convention used
  throughout this study.

ONLY VALID MEASUREMENTS ARE TIMES

  A cell carries a number only where the run finished and the driver confirmed
  the target was reached.  Everything else is a word, never a number:

  TIMEOUT means the solver did not finish inside the 1200 s cap.  MEMORY means
  it ran out of memory -- address space, heap or stack, which for the six
  exports is the same event seen from several sides.  Where a smaller size in
  the same family already failed, the larger sizes were not run at all: a
  solver that cannot do n is not going to do 2n, and the machine time is
  better spent elsewhere.  Those carry the same word.  average_ms then covers
  only the problems that did finish, so two rows are comparable only when both
  say finished = 10.

  A failed run's clock is never averaged in even when it produced one.  A run
  killed for memory burned time before it died, and that time is not a solve
  time; it stays in the raw rows and out of the tables.

  RUNS KILLED BY THE KERNEL.  8 runs were taken down by the kernel's
  out-of-memory killer: killed by signal 9, nothing on stderr, no time.  The
  runner recorded them as ERROR (rc=-9 in its log) because the driver itself
  said nothing; they are shown here as MEMORY, which is what they are, and the
  raw rows keep the ERROR as written.  They are, by column:
    scala_csr     8   Dense-n.15.0.gr#0 rep=1, Dense-n.15.0.gr#0 rep=2, Dense-n.15.1.gr#0 rep=1, Dense-n.15.2.gr#0 rep=1, Dense-n.15.2.gr#0 rep=2, Dense-n.15.3.gr#0 rep=1, Dense-n.15.3.gr#0 rep=2, Dense-n.15.4.gr#0 rep=1
  Every one of them is a scala_csr run on Dense-n at n = 32768, where the
  other repeats or instances of the same solver died of heap exhaustion in
  the ordinary way; the runner does not infer from ERROR, so these instances
  were run again until a repeat said MEMORY.

  sml_csr on the NY road network (264346 nodes): the ten problems of that
  rung come from campaign rerun_ny_20261012_101143, run one at a time with
  nothing else on the machine, same driver, same pairs, same cap; the table
  and sml_csr/raw/USA-road-t.csv alike hold that rung.

TWO CAMPAIGNS, AND WHICH COLUMNS COME FROM WHICH

  Ten columns are from the campaign of 2026-10-11 (results/20261011_131341):
  the six exports, networkx, and the first-campaign library columns
  lemon_linked, jgrapht_hashgraph and scipy_prebuilt.  Three columns --
  lemon_csr, jgrapht_csr and scipy_csr -- are from the campaign of
  2026-10-14 (results/20261014_161905), which measured those three solvers
  again with their graph structure built inside the clock, as explained
  under THE CLOCK.  Each column's conditions.txt is the one its own campaign
  wrote.  The same instances, the same source-target pairs, the same cap,
  the same pinning and the same machine in both.

  The first campaign ran in two parts (flags_resumed_20261011_230825.txt
  marks the second); in the second part the remaining phases ran in the
  groups (scala_csr, go_csr) and (scala_rbt, go_rbt) instead of (scala_csr,
  scala_rbt) and (go_csr, go_rbt).  Each group finished every family, size
  and repeat before the next began.

THE CLOCK

  Every time in this archive is one quantity and one only: the difference
  between two readings of the CPU clock, user plus system.  The first is
  taken immediately before the clocked period opens -- after the input has
  been parsed, and for the JVM solvers after the warm-up -- and the second
  immediately on return.  Nothing stands between the two readings.

  For OUR SIX EXPORTS the whole verified program lies between the two
  readings.  The entry point builds its own structures inside the call, so
  that setup is measured: for the imperative export that is the CSR, and for
  the functional one the adjacency map of red-black trees, which is the
  dominant cost and is exactly why it is not hidden.  That is the point of
  the study: a benchmark of generated code has to cover the whole generated
  program.

  THE TWO EXPORTS TAKE THEIR GRAPH DIFFERENTLY, and the clock follows each of
  them.  The imperative export takes the vertex count and the parser's own
  two arc arrays, so there is nothing to marshal and the number here is the
  whole of it.  The functional export takes a cons LIST of (tail, head) pairs
  instead; turning the arrays into that list is the counterpart of filling
  the arrays themselves, which no study has ever put inside the clock, so it
  falls outside the two readings and is NOT counted here.  The campaign
  directory records it separately, for a reader who would rather count it in.

  THE LIBRARIES are held to one rule since 2026-10-14, the same one that
  decides for the exports.  A structure that can be filled arc by arc while
  the file is read may be built outside the two readings.  A structure that
  needs the complete arc list first is built after parsing, in a pass of its
  own, and that build is the first part of the measured period; the search
  is the second.  The three library solvers measured both ways are here
  both ways; the next section says what each column's structure is and
  where its clock opens.

  NO PARALLEL ARCS WERE COLLAPSED anywhere in this study, and that is honest
  rather than padding.  The Dijkstra study had to collapse them to their
  cheapest member before handing a graph to SciPy or NetworkX, because one
  ADDS the weights of arcs sharing a pair and the other OVERWRITES them.  An
  unweighted graph has nothing to add or overwrite, and parallel arcs change
  no breadth-first answer, so nothing was collapsed.

  THE JGRAPHT CLOCK differs between the two JGraphT columns.  jgrapht_csr is
  on the solver thread's CPU clock PLUS the collector's time: the thread
  clock from ThreadMXBean, and the collector's accumulated pause time from
  the JVM's GarbageCollectorMXBeans, both read before and after the call and
  the differences added.  Under the serial collector a collection happens
  only because the measured thread allocated and only while that thread
  waits, so the sum is that thread's work plus the collecting done for it,
  and nothing else.  The whole-process clock was tried instead and rejected
  with measurements: it counts the JIT compiler threads, which go on
  compiling inside the measured window after a warm-up that has run to
  silence (142 ms of a 184 ms search on a 65536-node graph), while
  collection in those windows was nil.  jgrapht_hashgraph, from the first
  campaign, is on the bare thread clock, which drops the collector's work,
  after a warm-up on a synthetic graph.

  THE TWO SCALA COLUMNS ARE ON THE BARE SOLVER THREAD'S CLOCK, as in the
  campaign that measured them, so collection the solver itself caused does
  not enter their number.  Against the whole-process clock over the same runs
  the gap has a median of 2.0x for scala_csr and 1.1x for scala_rbt; the
  whole-process figure also carries the JIT compiler threads, so the true
  correction is smaller than that gap, but it is not zero.  Those two columns
  are our own exports and the understatement runs in our favour, so they
  should be read as lower bounds.

  THE JVM WARM-UP of jgrapht_csr runs the measured call on the measured
  instance itself, from the measured source, before the clock opens, round
  after round until the compiler has been quiet for two rounds and at least
  two seconds of rounds have gone by (at most 200 rounds or 60 s).  An
  instance over 2^18 arcs is warmed on its own induced subgraph on the first
  n' nodes that fit that budget.  The warm-up spins rather than sleeps while
  it waits for the compiler, so the core is busy when the clock opens.

  The campaign directory holds the unaggregated rows, where the time spent
  outside those two readings and the wall clock stand beside this number.
  This archive carries the measurement alone.

THE DATA STRUCTURES, COLUMN BY COLUMN

  Every solver walks the same graph; what differs is the structure it walks
  and whether building that structure is inside the clock.

    sml_csr, scala_csr, go_csr
                  CSR arrays (offsets and a packed arc array) built by the
                  exported code from the parser's two arc arrays, plus the
                  queue and the distance/parent arrays.  INSIDE the clock.
    sml_rbt, scala_rbt, go_rbt
                  an adjacency map of red-black trees, and red-black trees
                  for the search state, built by the exported code from a
                  cons list of arcs.  INSIDE (the cons list is marshalling,
                  built outside and recorded in results/).
    lemon_csr     LEMON's StaticDigraph: CSR, arcs sorted by tail, built by
                  build() from a complete tail-sorted arc list.  INSIDE: the
                  clock opens on the parsed pair list and covers the counting
                  sort by tail, build(), Bfs's own setup and the search,
                  rebuilt on every repeat.  Campaign of 2026-10-14.
    lemon_linked  LEMON's SmartDigraph: a linked arc list, every arc an
                  entry with next-out and next-in pointers, arcs in file
                  order, filled arc by arc as the file is read.  OUTSIDE:
                  the clock covers Bfs's setup and the search.  First
                  campaign, 2026-10-11.
    jgrapht_csr   jgrapht-opt's SparseIntDirectedGraph: a CSR boolean matrix
                  over integer vertices, constructed from the complete arc
                  list with NO_INCOMING_EDGES (forward arcs only).  INSIDE,
                  rebuilt on every repeat.  Campaign of 2026-10-14.
    jgrapht_hashgraph
                  jgrapht-core's DirectedPseudograph: an object per arc, a
                  hash map from vertex to its edge set and another from
                  edge to its endpoints, filled arc by arc as the file is
                  read.  OUTSIDE: the clock covers the iterator alone.
                  First campaign, 2026-10-11.
    scipy_csr     SciPy's csr_matrix, built by coo_matrix((data, (tails,
                  heads))).tocsr(), a sort-and-pack pass over the complete
                  arc arrays.  INSIDE, rebuilt on every repeat.  Campaign of
                  2026-10-14.
    scipy_prebuilt
                  the same csr_matrix, built once by the same call BEFORE
                  the clock opened; the clock covers breadth_first_order
                  alone.  First campaign, 2026-10-11.
    networkx      NetworkX's DiGraph, a dict of dicts, filled arc by arc as
                  the file is read.  OUTSIDE (first campaign only): this is a
                  structure that can genuinely be built while parsing.

  The raw rows of lemon_csr, jgrapht_csr and scipy_csr carry two columns
  the others do not, clock_build_ms and clock_solve_ms.  They come from ONE
  intermediate reading of the same clock, taken after the structure is built
  and before the search starts, and they add up to cpu_ms: the measured
  period split into its two parts.  They are not a second clock, and nothing
  in the tables is derived from them; they are there so that a reader can
  see how much of a library's time is the build.  The first-campaign
  drivers read the clock twice and their rows carry cpu_ms alone.
  Repacking the parsed arrays into a library's input list is marshalling in
  every column and stays outside.

NO EARLY EXIT, ANYWHERE

  Every solver sweeps the whole component reachable from the source; none of
  them stops when the target is first seen.  LEMON is called as Bfs::run(s),
  the one-argument form; the JGraphT iterator is drained to exhaustion, with
  cross-component traversal turned off so that it does not go on into
  components the source cannot reach; breadth_first_order and
  bfs_predecessors have no target argument at all.  The exports do the same.
  So a column is the cost of a full breadth-first sweep from that source, and
  the target only decides which answer is read off at the end.

ONE PROBLEM PER PROCESS

  A search problem is a graph AND a pair, so two pairs are two problems even
  on one graph.  Each was launched as its own process with its own --source
  and --target; no driver accepts a list of pairs.  Repeats got their own
  processes too, so no measurement was taken on a cache an earlier measurement
  had warmed.

  Runs were pinned one per L3 cache island, so no two concurrent runs shared
  any level of cache.  Cores 0-3 were kept free of measurement work, in both
  campaigns.  The solvers were measured in groups, a group finishing every
  family, size and repeat before the next began, so a fast solver never
  shared the machine with a slow one.

EVERY EDGE WEIGHT IS IGNORED

  The instances carry weights because they are the shortest-path challenge's
  files, and keeping them lets a BFS row and a Dijkstra row be read side by
  side on one graph and one pair.  No solver here reads them.

THE GRID

  Square-n     n = 1024 .. 2096704, twelve sizes, ten instances each
  Long-n       n = 1024 .. 2097152, twelve sizes, ten instances each
  Dense-n      n = 1024 .. 32768, six sizes, ten instances each
  USA-road-t   twelve road networks, NY (264346 nodes) .. USA (23947347),
               ten source-target pairs each
  three repeats of every problem

  The source-target pairs were drawn once from a recorded seed and are the
  same for every solver, so all columns answer exactly the same questions on
  exactly the same graphs.  Each pair is copied into the raw row beside the
  time it produced.  The seed and the draw are the Dijkstra study's, and that
  study's three families are the same files here, so their 360 pairs are
  bit-identical to its own.

THE FOUR FAMILIES, AND WHAT THEY ASK OF THE SEARCH

  Square-n is a square grid, sqrt(n) by sqrt(n), every interior node joined to
  its four neighbours, so there are very nearly 4n arcs and the degree is 4
  almost everywhere.  The ball around a source grows with the SQUARE of the
  radius, so the frontier is tens of thousands of nodes wide at the top sizes
  and the queue is long.

  Long-n is the same 4-regular construction squashed to sixteen rows and n/16
  columns, a long thin strip, again very nearly 4n arcs.  The frontier stays
  sixteen wide however large the graph gets, so the queue is short and the
  sweep is close to sequential in memory; what it pays instead is depth, tens
  of thousands of levels.

  Dense-n is this study's addition.  The DIMACS challenge shipped NO dense
  family: all six of its synthetic families sit at four arcs per node and its
  road networks are sparser still.  Dense-n was built with the challenge's own
  sprand generator at m = n^2/16, so the average degree grows with the graph,
  from 64 arcs per node at n=1024 to 2048 at n=32768.  The ladder stops at
  2^15 because the arc count squares: 2^15 is already 67 million arcs, about
  the size of the full USA network.  A search here finishes in two or three
  levels and almost all the work is scanning adjacency, not managing a queue
  -- which is the opposite of what the grids ask.

  USA-road-t is twelve real United States road networks, from New York up to
  the whole country at 23.9M nodes and 58.3M arcs.  Average degree is about
  2.4, far sparser than the grids, and the graphs are near-planar.  It is the
  only family whose sizes come from the world rather than from a generator,
  and the only one large enough that memory, not arithmetic, decides which
  solvers can run at all.

WHAT STOPS A LADDER

  Several solvers stop climbing well before the top, and the word in the cell
  says why.  The functional export is the main one: it holds the graph as a
  map of red-black trees, which costs both memory and pointer chasing, and it
  runs out of one or the other long before the imperative export does.  That
  gap between the two exports is the thing this study was built to show, and
  it is meant to be read off these tables directly.

  The Go builds carry a second ceiling, and it is the runtime's rather than
  the algorithm's.  The export turns Isabelle's loops into self-recursion and
  Go eliminates no tail calls, so the stack grows by a frame per arc; the Go
  runtime holds a goroutine stack to 2 GB however much the program asks for,
  and a stack overflow is recorded as MEMORY.  That is what stops go_csr in
  every family, and it stops it in the same place each time: its last finished
  rung carries between 1.0 and 2.7 million arcs and its first MEMORY rung
  between 3.9 and 4.2 million.  A go_csr MEMORY cell therefore says where the
  Go runtime stops, not where the verified program does -- the same export in
  Standard ML climbs well past it.

TOOLCHAINS AND FLAGS

  The campaigns' conditions files name the drivers but not their compilers,
  so they are listed here.  MLton 20241230 with -inline 10000 for the two SML
  exports; Scala 3.3.8 on JDK 21.0.12 with -Xmx45g -XX:ActiveProcessorCount=1
  -XX:+UseSerialGC for the two Scala exports; Go 1.27.2 for the two Go
  exports, with the goroutine stack raised to the runtime's maximum; g++
  11.4.0 against LEMON 1.3.1 for the LEMON drivers (-O2 -DNDEBUG in the
  first campaign, -O3 -march=native -DNDEBUG in the 2026-10-14 campaign); the same JDK and
  JVM flags, with jgrapht-core 1.5.3 (and jgrapht-opt 1.5.3 in the 2026-10-14 campaign),
  for JGraphT; Python 3.10.12 with scipy 1.15.3, numpy 2.2.6 and networkx
  3.4.2 for the Python solvers.  The build lines are bench/build_all.sh and
  the launch lines are each driver's run.sh.

THE THIRTEEN COLUMNS

  ours, from two code exports of the same verified algorithm -- an imperative
  one over arrays (_csr) and a functional one over red-black trees (_rbt),
  each compiled to three languages:
    sml_csr           imperative export, Standard ML (MLton, -inline 10000)
    sml_rbt           functional export, Standard ML (MLton, -inline 10000)
    scala_csr         imperative export, Scala on the JVM, serial GC, -Xmx45g
    scala_rbt         functional export, Scala on the JVM, serial GC, -Xmx45g
    go_csr            imperative export, Go, stack raised to the runtime maximum
    go_rbt            functional export, Go, stack raised to the runtime maximum

  library implementations, for context; the three measured twice are
  listed as two solvers each:
    lemon_csr         LEMON 1.3.1 Bfs<StaticDigraph>: LEMON's CSR, built INSIDE the clock from the tail-sorted arc list, rebuilt every repeat; Bfs::run(s), no early exit; g++ 11.4.0 -O3 -march=native -DNDEBUG; 2026-10-14
    lemon_linked      LEMON 1.3.1 Bfs<SmartDigraph>: a linked arc list (arcs in file order, next-arc pointers), built OUTSIDE the clock; Bfs::run(s), no early exit; g++ 11.4.0 -O2 -DNDEBUG; 2026-10-11
    jgrapht_csr       JGraphT 1.5.3 BreadthFirstIterator on jgrapht-opt's SparseIntDirectedGraph: CSR, built INSIDE the clock, rebuilt every repeat; drained to exhaustion; JDK 21.0.12, serial GC, -Xmx45g; clock = thread CPU + collector time; warmed up on the instance itself; 2026-10-14
    jgrapht_hashgraph JGraphT 1.5.3 BreadthFirstIterator on DirectedPseudograph: an object per arc with hash maps from vertex to edge set and from edge to endpoints, built OUTSIDE the clock; drained to exhaustion; JDK 21.0.12, serial GC, -Xmx45g; bare thread CPU clock; warmed up on a synthetic graph; 2026-10-11
    scipy_csr         scipy 1.15.3 sparse.csgraph.breadth_first_order (Cython) on a CSR matrix built INSIDE the clock by coo_matrix(...).tocsr(), rebuilt every repeat; 2026-10-14
    scipy_prebuilt    scipy 1.15.3 sparse.csgraph.breadth_first_order (Cython) on the same CSR matrix, built by coo_matrix(...).tocsr() BEFORE the clock opened, once per process; 2026-10-11
    networkx          networkx 3.4.2 bfs_predecessors (pure Python), DiGraph (dict of dicts) filled while the file is read, outside the clock; 2026-10-11

Built 2026-10-15 01:06 by bench/build_results_zip.py from
    results/20261011_131341          sml_csr, sml_rbt, scala_csr, scala_rbt, go_csr, go_rbt, lemon_linked, jgrapht_hashgraph, scipy_prebuilt, networkx
    results/20261014_161905          lemon_csr, jgrapht_csr, scipy_csr
    results/rerun_ny_20261012_101143 sml_csr on USA-road-t at 264346 nodes
results/ holds the raw data; this holds the tables and, under raw/,
the driver rows stripped to the one canonical time per run.
