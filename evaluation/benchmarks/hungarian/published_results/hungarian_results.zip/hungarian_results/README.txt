Hungarian method study -- headline timings
==========================================

Fourteen columns on the three DIMACS assignment families: ten solvers, of
which the four library baselines measured on 2026-10-14 appear twice,
once as the sweeps of 2026-10-08 to 2026-10-10 measured them and once with
the structure build inside the clock.  One directory per column, one CSV per
family:

    <column>/low-cost.csv
    <column>/two-cost.csv
    <column>/geometric.csv
    <column>/conditions.txt    machine, versions, pinning and clock, exactly
                               as the campaign recorded them
    <column>/raw/              the unaggregated driver rows these tables
                               were built from
    COLUMNS.txt                which column comes from which file

CSV SHAPE

    nodes,left,s1,...,s10,finished,mean_ms

  one row per problem size.  nodes counts every vertex, left is the number of
  left vertices (nodes/2).  s1..s10 are the ten instances, by generator seed.
  finished says how many of the ten produced a time.  mean_ms, the last
  column, is the average over those.

  Each s<k> is the MEDIAN of that instance's three repeats, in milliseconds.
  Median within an instance, mean across instances: the convention used
  throughout this study.

  DNF means the solver did not finish that instance inside the 1200 s cap, or
  died on it (jgrapht_kuhnmunkres_thread on two-cost 32768 ran out of heap).
  In the campaigns with the ladder, where a smaller size in the same family
  already timed out the larger sizes were not run at all -- a solver that
  cannot do n is not going to do 2n, and the machine time is better spent
  elsewhere; those are DNF as well, with the raw row saying TIMEOUT_INFERRED
  and naming the instance it was inferred from.  The sweeps of 2026-10-08
  had no ladder and ran every size.  mean_ms is the average over the
  instances that did finish, and is blank when none did.

THE CLOCK

  Every time in this archive is one quantity and one only: the difference
  between two readings of the CPU clock, user plus system.  The first is
  taken immediately before the clocked period opens -- after the input has
  been parsed, and for the JVM solvers after the warm-up -- and the second
  immediately on return.  Nothing stands between the two readings.  Every
  driver read the clock twice; there is no build/solve split in this study.

  For OUR THREE EXPORTS the verified program lies between the two readings.
  The entry point `hungarian_csr_run_int' is handed the parser's own arc
  arrays and builds the CSR itself inside the call, so that setup is
  measured.  Reading the .asn file and computing the objective afterwards are
  outside, and so is nothing else.

  For THE REFERENCE SOLVERS one rule, applied in the campaign of
  2026-10-14: a solver gets its faster data structure; a structure that can
  be filled arc by arc while the file is read is built outside the two
  readings; one that needs the complete arc list first is built after
  parsing, and that build is the first part of the clocked period and the
  solve the second -- as it is for the exports' own CSR.  Reading the file
  and reading the objective back are outside for all of them.  The four
  baselines measured both ways are here both ways.

  WHERE THE TWO READINGS SIT, column by column:

    sml, go, scala    around hungarian_csr_run_int.  The CSR build is
                      between them, because the export does it itself.
    hybrid            around the verified program: from the instance being
                      parsed and in memory to the certificate checked and
                      the answer accepted.
    ortools           around solve() alone, which builds the library's own
                      graph itself from the arcs added before the first
                      reading; reading the cost is after the second.
    csa_q_csr         inside the C program: from immediately before the arc
                      list is packed into CSA's per-node arc arrays (a
                      counting sort over the complete list) to immediately
                      after the scaling loop.  Reading the arc lines is
                      before; the objective is computed after.
    csa_q_prebuilt    inside the C program, from after parse() returned --
                      the pack already done -- to after the scaling loop.
    scipy_lsa         around the solver call.  The dense cost matrix fills
                      while the file is read and is outside.
    scipy_mwfbm_csr   around the CSR matrix build and the solver call.
    scipy_mwfbm_prebuilt
                      around the solver call; the CSR matrix was built
                      before the first reading.
    jgrapht_kuhnmunkres_threadgc, jgrapht_kuhnmunkres_thread
                      around the constructor and getMatching().  The
                      hash-backed graph -- the faster structure for this
                      algorithm's getEdge lookups -- fills arc by arc and is
                      outside in both.  They differ in the clock: thread
                      clock plus the collector's time, against the bare
                      thread clock.
    jgrapht_mwbm_csr  around the build of jgrapht-opt's sparse CSR graph,
                      the constructor and getMatching().
    jgrapht_mwbm_hashgraph
                      around the constructor and getMatching(); the
                      hash-backed graph was built before the first reading.

  PINNING.  In the campaigns of 2026-10-10 and 2026-10-14 runs were pinned
  one per L3 cache island on cores 4 to 28, so no two concurrent runs shared
  any level of cache, and cores 0-3 were kept free of measurement work.  The
  sweeps of 2026-10-08 -- scipy_lsa, scipy_mwfbm_prebuilt,
  jgrapht_kuhnmunkres_thread and jgrapht_mwbm_hashgraph -- ran eight workers
  on cores 0, 4, 8, 12, 16, 20, 24 and 28, still one per island and sharing
  no cache, but with a worker on island 0-3; their conditions.txt records
  it.  The campaign of 2026-10-14 ran six workers on cores 8 to 28.

  THE JVM COLUMNS.  jgrapht_kuhnmunkres_threadgc and jgrapht_mwbm_csr are
  the solver thread's CPU clock (ThreadMXBean) PLUS the collector's pause
  time, read from the JVM's own counter: under the serial collector the VM
  thread collects while the measured thread stands still, so a thread clock
  alone drops that work.  The whole-process clock is not used, because it
  counts the JIT compiler threads.  jgrapht_kuhnmunkres_thread,
  jgrapht_mwbm_hashgraph and the scala column are on the bare thread clock:
  against the whole-process clock over the same runs the gap has a median
  of 1.6x for scala, part of which is the JIT, so those three columns should
  be read as lower bounds.  Every JGraphT driver warms the JIT on a seeded
  synthetic instance before the clock.

  ONE COLUMN'S SPLIT DOES NOT ADD UP EXACTLY.  In csa_q_csr and
  csa_q_prebuilt cpu_ms is CLOCK_PROCESS_CPUTIME_ID read inside the C
  program (measure.c), while cpu_usr_ms and cpu_sys_ms come from getrusage
  around the same span, a coarser source; the two parts differ from cpu_ms
  by up to 0.03 ms.  cpu_ms is the measurement.

  The campaign directories hold the unaggregated rows, where the time spent
  outside the two readings and the wall clock stand beside this number.
  This archive carries the measurement alone.

THE DATA STRUCTURES, COLUMN BY COLUMN

    sml, scala, go  CSR arrays over the left vertices (offsets, packed right
                    endpoints and costs), built by the exported code from
                    the parser's arc arrays, plus its own potentials and
                    matching arrays.  INSIDE the clock.
    hybrid          CSA's structures for the oracle, the verified checker's
                    arrays, and the export's CSR for the fallback; all
                    INSIDE.
    csa_q_csr       CSA's per-node arc arrays: arcs packed by tail with
                    per-node offsets, a CSR, built by a counting sort over
                    the complete arc list.  INSIDE.
    csa_q_prebuilt  the same arrays, packed before the clock opened.  OUTSIDE.
    ortools         OR-Tools' own graph (util::ListGraph, then
                    LinearSumAssignment::FinalizeSetup) built from the arc
                    vectors inside solve().  INSIDE by construction.
    scipy_lsa       a dense left-by-right cost matrix, filled arc by arc as
                    the file is read (absent arcs at a prohibitive cost on
                    low-cost and two-cost).  OUTSIDE.
    scipy_mwfbm_csr SciPy's csr_matrix of costs, built by csr_matrix((w,
                    (rows, cols))), a sort-and-pack pass over the complete
                    arrays.  INSIDE.
    scipy_mwfbm_prebuilt
                    the same csr_matrix, built before the clock opened.
                    OUTSIDE.
    jgrapht_kuhnmunkres_threadgc, jgrapht_kuhnmunkres_thread
                    jgrapht-core's SimpleWeightedGraph: an object per edge,
                    a hash map from vertex to its edge set, filled arc by
                    arc as the file is read, complete on every family
                    (absent arcs added at a prohibitive cost).  OUTSIDE in
                    both; the structure is the faster one for this
                    algorithm's |X|*|Y| getEdge lookups.
    jgrapht_mwbm_csr
                    jgrapht-opt's SparseIntUndirectedWeightedGraph: a CSR
                    graph over integer vertices with a weight per edge,
                    constructed from the complete edge list.  INSIDE.
    jgrapht_mwbm_hashgraph
                    jgrapht-core's SimpleWeightedGraph, as above, filled
                    while the file is read.  OUTSIDE.

THE GRID

  low-cost   n = 2048, 4096, 8192, 16384, 32768
  two-cost   n = 2048, 4096, 8192, 16384, 32768
  geometric  n = 256, 512, 1024, 2048, 4096
  ten instances per size (seeds 1..10), three repeats each

  These are the sizes the 13th DIMACS Implementation Challenge uses for the
  assignment problem.  Nothing here goes beyond them.

THE FOURTEEN COLUMNS

  ours, from one code export, with theta and cap fixed at the call site:
    sml                           our verified export, Standard ML (MLton, inline 10000)
    scala                         our verified export, Scala (JVM)
    go                            our verified export, Go

  the certifying hybrid:
    hybrid                        the certifying hybrid: csa_q as an untrusted oracle, verified checker, verified Hungarian method as the fallback

  the two reference solvers the DIMACS challenge names (CSA twice):
    csa_q_csr                     CSA (Goldberg & Kennedy), DIMACS reference solver, build csa_q; the clock opens before CSA packs the arc list into its per-node arc arrays (a CSR); with the ladder; 2026-10-14
    csa_q_prebuilt                the same csa_q binary's algorithm, with the arc-array pack done BEFORE the clock opened; 2026-10-10
    ortools                       OR-Tools linear_sum_assignment, DIMACS reference solver

  library implementations, for context; the three measured twice are
  listed as two solvers each:
    scipy_lsa                     scipy.optimize.linear_sum_assignment (dense cost matrix, filled while the file is read, outside the clock)
    scipy_mwfbm_csr               scipy.sparse.csgraph.min_weight_full_bipartite_matching; the CSR matrix is built INSIDE the clock; with the ladder; 2026-10-14
    scipy_mwfbm_prebuilt          scipy.sparse.csgraph.min_weight_full_bipartite_matching on the same CSR matrix, built BEFORE the clock opened; 2026-10-08
    jgrapht_kuhnmunkres_threadgc  JGraphT KuhnMunkresMinimalWeightBipartitePerfectMatching (the Hungarian method) on a hash-backed SimpleWeightedGraph filled while the file is read, outside the clock; thread clock PLUS collector time; with the ladder; 2026-10-14
    jgrapht_kuhnmunkres_thread    the same algorithm on the same hash-backed graph, outside the clock; bare thread clock, without the collector's time; no ladder; 2026-10-08
    jgrapht_mwbm_csr              JGraphT MaximumWeightBipartiteMatching (LEDA, shortest augmenting paths) on jgrapht-opt's SparseIntUndirectedWeightedGraph, a CSR graph, built INSIDE the clock; thread clock plus collector time; with the ladder; 2026-10-14
    jgrapht_mwbm_hashgraph        JGraphT MaximumWeightBipartiteMatching on a hash-backed SimpleWeightedGraph (an object per edge), built OUTSIDE the clock; bare thread clock; no ladder; 2026-10-08

  csa ships 44 compile-time combinations of the same algorithm and they are
  not close to each other in speed.  csa_q (-DQUEUE_ORDER, costs as doubles)
  was chosen by measuring the authors' own shortlist of 14 builds on the
  largest size of each family.  No build wins all three families; csa_q has
  the best worst case, tied with csa_s_spo.  That probe is not in this zip.

  Objective values agree across all columns on every instance that
  finished.  This is a speed comparison only.

built 20261015_011552 from
  results/20261010_115840          our three exports
  results/20261010_191214          the certifying hybrid
  results/20261010_165412          ortools and csa_q_prebuilt
  results/scipy_core.csv           scipy_lsa and scipy_mwfbm_prebuilt
  results/jgrapht_20261008_203157.csv
                                   jgrapht_kuhnmunkres_thread and
                                   jgrapht_mwbm_hashgraph
  results/20261014_190404          csa_q_csr, scipy_mwfbm_csr,
                                   jgrapht_kuhnmunkres_threadgc,
                                   jgrapht_mwbm_csr: measured 2026-10-14
                                   with the structure build inside the clock
                                   and the ladder (a timeout at one size
                                   stops the larger sizes of that solver and
                                   family).


Every column that is not the difference between the two canonical CPU-clock
readings is left out of the raw rows: the second clock, the wall clock, the
regions outside the solver call, and the hybrid's absolute stamps and
per-phase spans.  The campaign directories hold all of it.
