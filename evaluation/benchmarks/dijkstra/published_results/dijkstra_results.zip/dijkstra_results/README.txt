Dijkstra study -- headline timings
==================================

Ten columns on three shortest-path families: the two grid families of the
9th DIMACS Implementation Challenge and its USA road networks.  Seven solvers
-- one verified Isabelle export in three languages and four libraries -- of
which three libraries appear twice, once on the structure the first campaign
gave them and once on CSR built inside the clock.  One directory per column,
one CSV per family:

    <column>/Square-n.csv
    <column>/Long-n.csv
    <column>/USA-road-t.csv
    <column>/conditions.txt    machine, versions, pinning and clock, exactly
                               as the campaign recorded them, plus an added
                               paragraph per library column saying which
                               structure it was given and what the clock
                               covers
    <column>/raw/              the unaggregated driver rows these tables
                               were built from, stripped to the one clock
    COLUMNS.txt                which column comes from which directory

CSV SHAPE

    nodes,s1,...,s10,finished,average_ms              the two grid families
    nodes,instance,q1,...,q10,finished,average_ms     the road networks

  One row per problem size.  The two grid families put TEN INSTANCES at each
  size and ask one question of each, so s1..s10 are the ten instances.  The
  road family has one real network per size and asks TEN QUESTIONS of it, so
  q1..q10 are the ten source-target pairs and the network's name sits beside
  its node count.  Either way a column is one shortest-path problem.

  finished says how many of the ten produced a time.  average_ms, the last
  column, is the average over those.

  Each cell is the MEDIAN of that problem's three repeats, in milliseconds.
  Median within a problem, mean across problems: the convention used
  throughout this study.

  TIMEOUT means the solver did not finish inside the 1200 s cap.  MEMORY
  means it ran out of memory -- address space or stack, which for the three
  exports is the same event seen from two sides.  ERROR means the run died
  without the driver reporting a time or a reason the runner could classify;
  in this study every ERROR cell is scala on the USA network, where the
  driver's 24 GB solve stack overflowed (two runs) or the kernel's
  out-of-memory killer took the run down (five runs), both before the runner
  learned, on 2026-10-11 09:25, to record a stack overflow as MEMORY (the
  go column's overflows carry that word).  Same event, two words, by date.
  Where a smaller size in the same family already failed, the larger sizes
  were not run at all: a solver that cannot do n is not going to do 2n, and
  the machine time is better spent elsewhere.  Those carry the same word.
  average_ms then covers only the problems that did finish, so two rows are
  comparable only when both say finished = 10.

TWO CAMPAIGNS

  sml, scala, go and networkx come from the campaign of 2026-10-11, and so
  do lemon_linked, jgrapht_hashgraph and scipy_prebuilt, the three libraries
  as that campaign measured them: LEMON on SmartDigraph, a linked arc list;
  JGraphT on an object-per-arc graph; SciPy with the CSR build outside the
  clock.  lemon_csr, jgrapht_csr and scipy_csr come from the campaign of
  2026-10-14, which measured those three with CSR built inside the clock.  Same instances, same source-target pairs, same machine, same
  pinning, same cap.  COLUMNS.txt says it per column.

  The go column was measured in two passes: the runs above the Go stack
  ceiling of the first pass were measured in a second pass with the stack
  raised (go's conditions.txt); every problem has exactly one row.

THE CLOCK

  CPU time (user + system), read immediately before the solver call and
  immediately on return, with nothing else between the readings.

  The rule applied since 2026-10-14: a structure that can be filled arc by
  arc while the file is read may be built outside the clock; a structure
  that needs the complete arc list is built after parsing, and that build is
  the first part of the clocked period, the search the second.

  For OUR THREE EXPORTS the whole verified program is measured.  The entry
  point is handed plain arc arrays and builds its own CSR and its own heap
  inside the call, so that setup is inside the clock.  That is the point of
  the study: a benchmark of generated code has to cover the whole generated
  program.

  For LEMON_CSR, JGRAPHT_CSR AND SCIPY_CSR the structure build is inside the
  clock too.  Each is given its CSR graph -- LEMON's StaticDigraph,
  jgrapht-opt's SparseIntDirectedWeightedGraph, SciPy's csr matrix -- and a
  CSR graph cannot be built while the file is read: it takes the complete
  arc list (tail-sorted, for LEMON) and walks it in a separate pass, exactly
  as the exports do.  So the clock opens on the filled arc list and covers
  the sort, the build, the algorithm's own setup and the search, with a
  fresh build on every repeat.  Repacking the parsed arrays into the
  library's input list is marshalling and stays outside; results/ records it.

  The raw rows of these three columns carry the clocked period in its two
  parts, clock_build_ms (the structure build) and clock_solve_ms (the search),
  which add up to cpu_ms.  They are one interval read once in the middle, not
  a second clock.  At the largest size of each family the build is 40 to 52
  per cent of LEMON's clocked period, 5 to 17 per cent of SciPy's and 56 to
  75 per cent of JGraphT's (the sum of the build parts over the sum of the
  clocked periods of the thirty runs of that rung).

  For LEMON_LINKED, JGRAPHT_HASHGRAPH AND SCIPY_PREBUILT, the first
  campaign's columns, the structure build is outside the clock, as that
  campaign's conditions.txt says: the clock covers the algorithm's setup and
  the search on a structure built before it opened.

  For NETWORKX the structure build sits outside the clock: its dict-of-dicts
  graph is filled arc by arc and could genuinely be built while parsing.

  THE JGRAPHT CLOCK differs between the two JGraphT columns.  jgrapht_csr is
  the solver thread's CPU clock PLUS the collector's pause time, read from
  the JVM's own counter.  The JVM runs the serial collector on one
  processor, so the collector works only while the measured thread waits
  for it, and a thread clock alone would drop that work.  The process clock
  was tried and rejected: it counts the JIT compiler threads, which go on
  compiling inside the measured window after any warm-up this study can
  afford, while collection in those windows was nil.  Before the clock
  opens that driver warms the JIT ON THE INSTANCE ITSELF (bounded to a
  subgraph of 2^18 arcs for the large ones), through the very same
  build-and-solve function the measurement uses, until the compiler has been
  quiet for two rounds; between rounds it spins, yielding, rather than
  sleeps, because this machine's governor clocks an idle core down to
  1.5 GHz and a sleeping warm-up handed the clock a cold core.  In
  jgrapht_csr's raw rows cpu_usr_ms is the thread's user time plus the
  collector's time and cpu_sys_ms the thread's system time, so the two
  still add up to cpu_ms.  jgrapht_hashgraph, from the first campaign, is
  on the bare thread clock, which drops the collector's work, after a
  warm-up on a synthetic graph; the scala column is on that same bare
  thread clock.

  Wall time was recorded too, but nothing here is derived from it: seven runs
  shared the machine, so wall time carries what the other six were doing and
  CPU time does not.  It stays in results/ with the other out-of-clock
  timings.

THE DATA STRUCTURES, COLUMN BY COLUMN

  Every solver walks the same weighted graph; what differs is the structure
  it walks and whether building that structure is inside the clock.

    sml, scala, go
                  CSR arrays (offsets, packed heads and lengths) built by
                  the exported code from the parser's arc arrays, plus its
                  own binary heap and distance arrays.  INSIDE the clock.
    lemon_csr     LEMON's StaticDigraph: CSR, arcs sorted by tail, built by
                  build() from a complete tail-sorted arc list, with the
                  length map laid over the new arc ids.  INSIDE: the clock
                  opens on the parsed pair list and covers the counting
                  sort by tail, build(), the length map, Dijkstra's own
                  setup and the search, rebuilt on every repeat.  Campaign of
                  2026-10-14.
    lemon_linked  LEMON's SmartDigraph: a linked arc list, every arc an
                  entry with next-out and next-in pointers, arcs in file
                  order, filled arc by arc as the file is read, with its
                  length map.  OUTSIDE: the clock covers Dijkstra's setup
                  and the search.  First campaign, 2026-10-11.
    jgrapht_csr   jgrapht-opt's SparseIntDirectedWeightedGraph: a CSR
                  matrix over integer vertices with a weight per arc,
                  constructed from the complete arc list with
                  NO_INCOMING_EDGES (forward arcs only).  INSIDE, rebuilt
                  on every repeat.  Campaign of 2026-10-14.
    jgrapht_hashgraph
                  jgrapht-core's DirectedWeightedPseudograph: an object per
                  arc holding its weight, a hash map from vertex to its
                  edge set and another from edge to its endpoints, filled
                  arc by arc as the file is read.  OUTSIDE: the clock
                  covers the shortest-path call alone.  First campaign,
                  2026-10-11.
    scipy_csr     SciPy's csr_matrix of weights, built by coo_matrix((w,
                  (tails, heads))).tocsr(), a sort-and-pack pass over the
                  complete arc arrays, after parallel arcs were collapsed
                  to their cheapest member outside the clock (csr summing
                  would add them).  INSIDE, rebuilt on every repeat.
                  Campaign of 2026-10-14.
    scipy_prebuilt
                  the same csr_matrix, built once by the same call BEFORE
                  the clock opened; the clock covers csgraph.dijkstra alone.
                  First campaign, 2026-10-11.
    networkx      NetworkX's DiGraph, a dict of dicts with the weight as an
                  attribute, filled arc by arc as the file is read, parallel
                  arcs collapsed to the cheapest (an insert overwrites).
                  OUTSIDE (first campaign only).

BUILD FLAGS

  LEMON driver    g++ 11.4.0 -O3 -march=native -DNDEBUG -std=c++14 in the
                  2026-10-14 campaign (lemon_csr); -O3 -DNDEBUG -std=c++14 in the first
                  campaign (lemon_linked); LEMON 1.3.1 in both
  JGraphT         JDK 21.0.12.1, -Xmx45g -XX:ActiveProcessorCount=1
                  -XX:+UseSerialGC, jgrapht-core 1.5.3; jgrapht-opt 1.5.3
                  in the 2026-10-14 campaign
  SciPy           1.15.3, the study's own .venv, BLAS threads pinned to one
  SML export      MLton 20241230 (drivers/sml/solve_sml.mlb)
  Scala and Go    as recorded in their conditions.txt

ONE PROBLEM PER PROCESS

  A shortest-path problem is a graph AND a pair, so two pairs are two problems
  even on one graph.  Each was launched as its own process with its own
  --source and --target; no driver accepts a list of pairs.  Repeats got their
  own processes too, so no measurement was taken on a cache an earlier
  measurement had warmed.

  Runs were pinned one per L3 cache island, so no two concurrent runs shared
  any level of cache.  Cores 0-3 were kept free of measurement work, in both
  campaigns.

THE GRID

  Square-n     n = 1024 .. 2096704, twelve sizes, ten instances each
  Long-n       n = 1024 .. 2097152, twelve sizes, ten instances each
  USA-road-t   twelve road networks, NY (264346 nodes) .. USA (23947347),
               ten source-target pairs each
  three repeats of every problem

  The source-target pairs were drawn once from a recorded seed and are the
  same for every solver, so all columns answer exactly the same questions on
  exactly the same graphs.  Each pair is copied into the result row beside the
  time it produced.

THE THREE FAMILIES, AND WHAT THEY ASK OF THE ALGORITHM

  Square-n is a square grid, sqrt(n) by sqrt(n), every interior node joined to
  its four neighbours, so there are very nearly 4n arcs and the degree is 4
  almost everywhere.  Arc weights are drawn uniformly from [0, n], so the
  weight range grows with the graph and the cheapest route wanders rather than
  running straight: at 2.1M nodes it takes about 1,070 arcs.  The ball around
  a source grows with the SQUARE of the radius, so a search that must reach a
  random target settles most of the graph and carries a frontier tens of
  thousands of nodes wide -- this is the family that stresses the heap.

  Long-n is the same 4-regular grid construction squashed to sixteen rows and
  n/16 columns, a long thin strip, again with very nearly 4n arcs and weights
  uniform in [0, n].  Because the strip is only sixteen wide the frontier
  stays narrow and the ball grows only LINEARLY with the radius, so the heap
  stays small and the sweep is close to sequential in memory.  What it pays
  instead is path length: at 2.1M nodes the shortest route runs about 69,310
  arcs, sixty times Square-n at the same size, so the distance labels are
  revised over and over down a chain.

  USA-road-t is twelve real United States road networks with travel-time
  weights, from New York up to the whole country at 23.9M nodes and 58.3M
  arcs.  Average degree is 2.44, far sparser than the grids, the graphs are
  near-planar, and the weights are strongly structured: motorways make long
  cheap jumps, so the settled region is stretched along a few corridors rather
  than round.  It is the only family whose sizes come from the world rather
  than from a generator, and the only one large enough that memory, not
  arithmetic, decides which solvers can run at all.

  None of the three is friendly in the sense that matters most to a
  point-to-point search.  The targets are random and the weights are spread
  wide, so stopping at the first settled target saves little: the region the
  solver settles grows in step with the graph, and the measured cost per arc
  stays flat all the way up each ladder -- for the SML export, between about
  100 and 210 nanoseconds per arc from the smallest instance to the largest,
  in every family.  Had the early exit been doing real work, that number would
  fall as the graphs grew, and it does not.

  Compared at a matched arc count -- the two grids at their top rung against
  the LKS and E road networks, seven to nine million arcs each -- the cost per
  arc and per node of the tables here is:

                         ns per arc                  ns per node
                   Square  Long   LKS    E     Square   Long   LKS    E
      sml            202    186   165  175       809    719   413  427
      lemon_csr       82     67    60   60       330    261   151  147
      scipy_csr      221    161   176  188       883    624   439  459
      jgrapht_csr    793    841   612  650      3172   3259  1528  1585

  (lemon_csr, scipy_csr and jgrapht_csr with the structure build inside the
  clock; sml from the first campaign, where it always was.)

  For the SML export, LEMON and SciPy, Square-n is the dearest family per arc
  -- its frontier is tens of thousands of nodes wide, which costs both heap
  operations and cache misses -- and the road networks are the cheapest per
  node for every solver, because a road node carries 2.4 arcs where a grid
  node carries four.  JGraphT is the one solver that finds Long-n dearer than
  Square-n, and it costs three to four times the others per arc; 56 to 75 per
  cent of its clocked period at these sizes is the building of its sparse
  graph, which the clock_build_ms column shows directly.  The differences
  between families are real but modest -- well under a factor of two for any
  one solver -- and that is the honest summary: these three families stress
  different parts of the machine, but none of them lets a correct Dijkstra
  implementation off lightly.

THE TEN COLUMNS

  ours, from one code export:
    sml               our verified export, Standard ML (MLton, -inline 10000)
    scala             our verified export, Scala on the JVM, 24 GB of solve stack
    go                our verified export, Go, stack raised to the runtime maximum

  library implementations, for context; the three measured twice are
  listed as two solvers each:
    lemon_csr         LEMON 1.3.1 Dijkstra<StaticDigraph> (C++): LEMON's CSR, built INSIDE the clock from the tail-sorted arc list, rebuilt every repeat; binary heap; g++ 11.4.0 -O3 -march=native -DNDEBUG; 2026-10-14
    lemon_linked      LEMON 1.3.1 Dijkstra<SmartDigraph> (C++): a linked arc list (arcs in file order, next-arc pointers), built OUTSIDE the clock; binary heap; g++ 11.4.0 -O3 -DNDEBUG; 2026-10-11
    jgrapht_csr       JGraphT 1.5.3 IntVertexDijkstraShortestPath (Java) on jgrapht-opt's SparseIntDirectedWeightedGraph: CSR, built INSIDE the clock, rebuilt every repeat; 4-ary heap; clock = thread CPU + collector time; warmed up on the instance itself; 2026-10-14
    jgrapht_hashgraph JGraphT 1.5.3 IntVertexDijkstraShortestPath (Java) on DirectedWeightedPseudograph: an object per arc with hash maps from vertex to edge set and from edge to endpoints, built OUTSIDE the clock; 4-ary heap; bare thread CPU clock; warmed up on a synthetic graph; 2026-10-11
    scipy_csr         scipy 1.15.3 sparse.csgraph.dijkstra (Fibonacci heap, Cython) on a CSR matrix built INSIDE the clock by coo_matrix(...).tocsr(), rebuilt every repeat; 2026-10-14
    scipy_prebuilt    scipy 1.15.3 sparse.csgraph.dijkstra (Fibonacci heap, Cython) on the same CSR matrix, built by coo_matrix(...).tocsr() BEFORE the clock opened, once per process; 2026-10-11
    networkx          networkx 3.4.2 single_source_dijkstra (pure Python); its dict graph is filled while the file is read, so built outside the clock; 2026-10-11

Built 2026-10-15 01:09 by bench/build_results_zip.py from 20261011_011214 and 20261014_170554.
results/ holds the raw data; this holds only the tables and
the stripped rows they were built from.
