Dijkstra study -- the published tables and raw rows (Tables 13 to 15)
=====================================================================

One directory per column, one CSV per family:

    <column>/Square-n.csv, Long-n.csv, USA-road-t.csv
    <column>/conditions.txt    machine, versions, pinning and clock, as the
                               campaign recorded them, plus a note per library
                               column on its structure and clock
    <column>/raw/<family>.csv  the driver rows the tables were built from, one
                               time per run
    COLUMNS.txt                which column comes from which results directory

CSV SHAPE

    nodes,s1,...,s10,finished,average_ms              the two grid families
    nodes,instance,q1,...,q10,finished,average_ms     the road networks

  One row per problem size.  The grid families put ten instances at each size
  and ask one question of each (s1..s10); the road family has one network per
  size and asks ten questions of it (q1..q10).  Each cell is the median of that
  problem's three repeats, in milliseconds; finished says how many of the ten
  produced a time; average_ms is the mean over those.

  A cell that is not a number: TIMEOUT (the 1200 s cap), MEMORY (out of
  address space or stack) or ERROR (the run died without the driver reporting
  a time or a reason the runner could classify; every ERROR cell is scala on
  the USA network, a stack overflow or a kill by the kernel's out-of-memory
  killer, the same event the go column reports as MEMORY).  Where a smaller
  size of the same family already failed, the larger sizes were not run and
  carry the same word.

THE CLOCK

  CPU time (user + system), read immediately before the solver call and
  immediately on return.

  The three exports: the whole verified program; the entry point is handed
  plain arc arrays and builds its own CSR and its own heap inside the call.

  The libraries: a structure that can be filled arc by arc while the file is
  read may be built outside the clock; one that needs the complete arc list
  is built after parsing, inside the clock, as the first part of the clocked
  period.  Three libraries are measured both ways:

    lemon_csr      LEMON's StaticDigraph (CSR), built by build() from the
                   tail-sorted arc list, with the length map laid over the new
                   arc ids.  INSIDE, rebuilt on every repeat: the clock covers
                   the counting sort by tail, build(), the length map,
                   Dijkstra's own setup and the search.
    lemon_linked   LEMON's SmartDigraph, a linked arc list with its length map,
                   filled as the file is read.  OUTSIDE: the clock covers
                   Dijkstra's setup and the search.
    jgrapht_csr    jgrapht-opt's SparseIntDirectedWeightedGraph, a CSR matrix
                   with a weight per arc, from the complete arc list
                   (NO_INCOMING_EDGES).  INSIDE, rebuilt on every repeat.
    jgrapht_hashgraph
                   jgrapht-core's DirectedWeightedPseudograph (an object per
                   arc, hash maps around it), filled as the file is read.
                   OUTSIDE: the clock covers the shortest-path call alone.
    scipy_csr      SciPy's csr_matrix of weights from coo_matrix(...).tocsr(),
                   after parallel arcs were collapsed to the cheapest outside
                   the clock (csr summing would add them).  INSIDE, rebuilt on
                   every repeat.
    scipy_prebuilt the same matrix, built once before the clock opened; the
                   clock covers csgraph.dijkstra alone.  OUTSIDE.
    networkx       NetworkX's DiGraph with the weight as an attribute, filled
                   as the file is read, parallel arcs collapsed to the cheapest.
                   OUTSIDE.

  The raw rows of lemon_csr, jgrapht_csr and scipy_csr carry clock_build_ms
  and clock_solve_ms, the two parts of the one clocked period from one
  intermediate reading; they add up to cpu_ms.  At the largest size of each
  family the build is 40 to 52 per cent of LEMON's clocked period, 5 to 17 per
  cent of SciPy's and 56 to 75 per cent of JGraphT's.  Repacking the parsed
  arrays into a library's input list is marshalling and stays outside.

  JGraphT: jgrapht_csr is on the solver thread's CPU clock plus the
  collector's pause time, warmed up on the instance itself (bounded to a
  subgraph of 2^18 arcs), spinning rather than sleeping between warm-up
  rounds; in its raw rows cpu_usr_ms is the thread's user time plus the
  collector's time.  jgrapht_hashgraph is on the bare thread clock after a
  warm-up on a synthetic graph; the scala column is on that same bare thread
  clock.  SciPy's Dijkstra has no target and settles the whole reachable graph
  (tag earlystop=no); the export, LEMON and NetworkX stop when the target is
  settled.  Predecessors are asked for from every solver.

ONE PROBLEM PER PROCESS

  A problem is a graph and a pair; each problem and each repeat was its own
  process, pinned one run per L3 cache island with cores 0-3 kept free of
  measurement work; the solvers were measured in groups.

THE GRID

  Square-n     n = 1024 .. 2096704, twelve sizes, ten instances each, weights uniform in [0, n]
  Long-n       n = 1024 .. 2097152, twelve sizes, ten instances each, weights uniform in [0, n]
  USA-road-t   twelve road networks with travel-time weights, NY (264346 nodes)
               .. USA (23947347), ten source-target pairs each
  three repeats of every problem.  The pairs were drawn once from a recorded
  seed and are the same for every solver; each is copied into its raw row.

THE TEN COLUMNS

  ours, one code export:
    sml               Standard ML, MLton 20241230 -inline 10000
    scala             Scala 3.3.8 on JDK 21.0.12, 24 GB of solve stack, bare thread clock
    go                Go 1.27.2, goroutine stack raised to the runtime maximum
  libraries:
    lemon_csr         LEMON 1.3.1 Dijkstra<StaticDigraph>, binary heap, CSR built INSIDE the clock; g++ 11.4.0 -O3 -march=native -DNDEBUG -std=c++14
    lemon_linked      LEMON 1.3.1 Dijkstra<SmartDigraph>, binary heap, linked arc list built OUTSIDE; g++ 11.4.0 -O3 -DNDEBUG -std=c++14
    jgrapht_csr       JGraphT 1.5.3 IntVertexDijkstraShortestPath (4-ary heap) on SparseIntDirectedWeightedGraph (jgrapht-opt), built INSIDE; JDK 21.0.12.1, -Xmx45g, serial GC; thread CPU + collector time
    jgrapht_hashgraph JGraphT 1.5.3 IntVertexDijkstraShortestPath on DirectedWeightedPseudograph, built OUTSIDE; bare thread CPU clock
    scipy_csr         scipy 1.15.3 sparse.csgraph.dijkstra (Fibonacci heap) on a CSR matrix built INSIDE
    scipy_prebuilt    the same call on the matrix built BEFORE the clock opened
    networkx          networkx 3.4.2 single_source_dijkstra on a DiGraph filled while the file is read
  The go column was measured in two passes: the runs above the Go stack
  ceiling of the first pass were measured again with the stack raised (go's
  conditions.txt); every problem has exactly one row.

WHERE THE ROWS COME FROM

    results/20261011_011214   sml, scala, go, networkx, lemon_linked, jgrapht_hashgraph, scipy_prebuilt
    results/20261014_170554   lemon_csr, jgrapht_csr, scipy_csr
