solver timings, one directory per solver, one CSV per problem and family
========================================================================

  <solver>/matching/low-cost.csv
  <solver>/matching/two-cost.csv
  <solver>/matching/geometric.csv
  <solver>/b_matching/...
  <solver>/weighted_matching/...
  <solver>/weighted_b_matching/...
  <solver>/conditions.txt     the flags.txt the campaign wrote beside the
                              raw CSVs: machine, versions, pinning, clock,
                              and anything that would change the numbers

This is the same layout as the hungarian study's solver_csvs.zip with one
level added, because this study runs four problems rather than one.  Note
that the campaign wrote a single flags.txt covering all five solvers, so
the five conditions.txt are copies of one file, not five different ones.

Everything here comes from one campaign, results/20261009_224301.  Nothing
preliminary is included: the inlining-threshold probe, the earlier driver
checks and the exploratory runs are all elsewhere in the tree and none of
them are in this zip.

Every CSV has the 13 columns the drivers all write, unchanged and
unaggregated -- nothing here is a median or a ratio:

  instance,n,seed,nodes,edges,status,cpu_ms,user_ms,sys_ms,card,weight,inferred_from,core

55 rows per file on low-cost and two-cost: 11 sizes x 5 seeds.
40 rows per file on geometric: 8 sizes x 5 seeds.  No repeats.
Sizes are 32..32768 on low-cost and two-cost, 32..4096 on geometric.
60 files, 3000 rows.

THE CLOCK

  Every time in this archive is one quantity and one only: the difference
  between two readings of the CPU clock, user plus system.  The first is
  taken immediately before the solver is called -- after the input has been
  parsed, and for the JVM solvers after the warm-up -- and the second
  immediately on return.  Nothing stands between the two readings.

  For OUR THREE EXPORTS the verified program lies between the two readings.
  Reading the file and computing the objective sit outside them.

  For THE TWO SAGE SOLVERS the structure build sits outside the two readings
  as well, which is inherent and favours them.  user_ms and sys_ms are empty
  on their rows: they report only a total.

  THE JVM COLUMNS ARE ON THE SOLVER THREAD'S CLOCK, read from ThreadMXBean,
  rather than the whole process's.  HotSpot's serial collector runs on the
  VM thread, so collection that the solver itself caused does not enter the
  number.  Against the whole-process clock over the same runs the gap has a
  median of 1.1x for scala.  The whole-process figure also carries the JIT
  compiler threads, so the true correction is smaller than that gap -- but
  it is not zero.  For a reference solver this understatement is
  conservative, since it flatters the library we are compared against; for
  OUR OWN SCALA EXPORT it runs the other way, and that column should be read
  as a lower bound.

  The campaign directory holds the unaggregated rows, where the time spent
  outside those two readings and the wall clock stand beside this number.
  This archive carries the measurement alone.

THE FIVE SOLVERS

  sml           the verified SML export, built with
                mlton -default-type int64 -inline 10000.  This is the
                main run; none of the build variants are in here.
  go            the Go export, go build with no flags
  scala         the Scala export, scalac, then java -Xmx16g
                -XX:ActiveProcessorCount=1 -XX:+UseSerialGC, 24576 MB
                stack on the measured thread, 3 warm-up calls before
                the clock starts
  sage_oracle   Sage's matroid intersection over the two partition
                matroids, with every independence query answered by a
                Python transcription of the verified oracle of our
                Isabelle instance
  sage_plain    the same two matroids built with Sage's own constructors
                instead -- PartitionMatroid for matching, and a
                RankMatroid from an explicit rank function for
                b-matching, since Sage has no capacitated partition
                matroid -- with all queries answered by Sage's generic
                implementations on top of the rank function.  This is
                the baseline a Sage user would write knowing nothing of
                our code.

Both Sage solvers call intersection_unweighted (Cunningham's blocking
flow, maximum cardinality) on the two unweighted problems and
intersection on the two weighted ones.  Sage's weighted routine returns
a maximum-weight common independent set, which need not have maximum
cardinality; the card column of a weighted Sage row can therefore be
below the card the same instance reaches unweighted, and that is correct
behaviour, not a short answer.  Arc values are weights to be maximised
throughout.

ROWS THAT ARE NOT A TIME

  A run that does not finish inside the 1200 s cap is recorded as
  timeout, with the time columns empty rather than set to the cap, so it
  can never be mistaken for a measurement.  A timeout ends the ladder:
  the larger sizes of that solver, problem and family are not run and are
  recorded as timeout_inferred, with the instance they were inferred
  from in the inferred_from column.  Of 3000 rows, 1926 are ok, 51 are
  timeout, 1007 are timeout_inferred and 16 are error.

  The 16 error rows are all Scala, all geometric, all "out of heap" at
  the -Xmx16g recorded in conditions.txt:

    matching/scala/geometric        n=2048 and n=4096, all 5 seeds each
    b_matching/scala/geometric      n=2048 all 5 seeds, n=4096 seed 1

  Read those exactly as a cap: they mean Scala cannot do this size here,
  and they do not get better at a larger size.  One wrinkle, left as it
  happened rather than tidied: b_matching/scala/geometric seed 2 at
  n=4096 ran out of time before it ran out of heap, so it is a genuine
  timeout and seeds 3 to 5 are inferred from it instead.

  The stopping rule was extended to end a ladder on out-of-memory as
  well as on the cap, but the change landed while this campaign was
  running and the orchestrator had already loaded the old rule.  So this
  campaign measured those sizes where a later one would infer them.
  That is more data, not less.

LARGEST SIZE EACH SOLVER FINISHED

  Every seed of the size below finished; the next size up did not.

                        low-cost   two-cost   geometric
  matching
    sml                    32768      32768        4096
    scala                  32768      32768        1024
    go                      8192       8192        1024
    sage_oracle             1024       1024         512
    sage_plain               512        512         256
  b_matching
    sml                    16384      16384        4096
    scala                   4096       4096        1024
    go                      2048       2048         512
    sage_oracle              512        512         512
    sage_plain               256        256         128
  weighted_matching
    sml                    32768      32768         256
    scala                  16384      16384         128
    go                      4096       8192         128
    sage_oracle             2048       2048         512
    sage_plain               256        256         128
  weighted_b_matching
    sml                    16384      16384         256
    scala                   4096       4096         128
    go                      2048       2048         128
    sage_oracle              512        512         128
    sage_plain               128        128          64

  A few leaves have a size at which some seeds finished and others timed
  out; the table above reports the last size where all five finished, so
  the CSVs carry a little more than it shows.

Rebuilt 2026-10-13.  Every column that was not the difference between the two
canonical CPU-clock readings has been removed: the second clock, the wall
clock, the regions outside the solver call, and the hybrid's absolute stamps
and per-phase spans.  Not one surviving number changed; the campaign
directories still hold everything that was taken out.
