DFS study -- headline timings
=============================

Sixteen columns on four depth-first-search families: two grid families of the
9th DIMACS Implementation Challenge on shortest paths, its USA road networks,
and a dense family built with the challenge's own generator.  Thirteen solvers
-- nine builds of three verified Isabelle exports and four libraries -- of
which three libraries appear twice, once on the structure the first campaign
gave them and once on CSR built inside the clock.  One directory per column,
one CSV per family:

    <column>/Square-n.csv
    <column>/Long-n.csv
    <column>/Dense-n.csv
    <column>/USA-road-t.csv
    <column>/conditions.txt    machine, versions, pinning and clock, exactly
                               as the campaign that produced the rows
                               recorded them
    <column>/raw/              the driver rows these tables were built from,
                               one time per run
    COLUMNS.txt                which column comes from which directory

CSV SHAPE

    nodes,s1,...,s10,finished,average_ms              the three generated families
    nodes,instance,q1,...,q10,finished,average_ms     the road networks

  One row per problem size.  The three generated families put TEN INSTANCES at
  each size and search one of them from one source, so s1..s10 are the ten
  instances.  The road family has one real network per size and searches it
  from TEN SOURCES, so q1..q10 are the ten sources and the network's name sits
  beside its node count.  Either way a column is one search problem: a graph
  and a source.

  finished says how many of the ten produced a time.  average_ms, the last
  column, is the average over those.

  Each cell is the MEDIAN of that problem's three repeats, in milliseconds.
  Median within a problem, mean across problems: the convention used
  throughout this study.

WHAT IS MEASURED

  A FULL GRAPH SEARCH: everything reachable from the source, settled once, by
  every solver.  The three verified exports are reachability searches that
  stop when the top of their stack equals a target; every run is given the
  target 0, which no DIMACS file names (ids run 1..n), so each export runs
  until its stack is empty.  Every driver refuses a target inside [1, n].
  The four reference solvers were chosen to do the same work and no more:
  LEMON's Dfs::run(s) (not run(s, t), which stops early, and not run(), which
  sweeps every component); JGraphT's DepthFirstIterator drained to exhaustion
  with cross-component traversal switched off; SciPy's depth_first_order from
  the source, which has no target and no restart; NetworkX's dfs_predecessors
  from the source, which walks that source's component only.

  The sources were drawn once at random from a recorded seed and are the same
  for every solver (instances/queries.csv in the study); each is copied into
  the raw row beside the time it produced.  Every edge weight is ignored: the
  files carry them so that a DFS, a BFS and a Dijkstra row can be read on one
  graph.

  THE CROSS-CHECK is the number of vertices visited.  Depth-first orders
  differ between implementations, so the order proves nothing; how many
  vertices come out is a property of the graph and the source alone.  Every
  solver that can report it reports the same number on every problem.  The
  raw rows carry it in `visited'; -1 means the export exposes no accessor for
  it (all three *_csr builds, and the two SML builds of *_lists and *_rbt,
  which are checked by proxy through the same export in Scala and in Go).

ONLY VALID MEASUREMENTS ARE TIMES

  A cell carries a number only where the sweep ran to exhaustion: status OK
  (the answer was read back and checked) or RAN (the two SML exports whose
  state is abstract; the sweep ran and nothing further is claimed).
  Everything else is a word, never a number:

  TIMEOUT means the solver did not finish inside the 1200 s cap.  MEMORY means
  it ran out of memory -- address space, heap or stack, which for the nine
  exports is the same event seen from several sides: the exports compile
  Isabelle's loops into recursion, neither the JVM nor the Go runtime
  eliminates tail calls, and a big enough instance runs the stack out rather
  than the heap.  Where a smaller size in the same family already failed, the
  larger sizes were not run at all: a solver that cannot do n is not going to
  do 2n.  Those carry the same word.  Where one repeat of a problem failed,
  the other repeats were not run either.  average_ms then covers only the
  problems that did finish, so two rows are comparable only when both say
  finished = 10.

  A failed run's clock is never averaged in even when it produced one.  A run
  killed for memory burned time before it died, and that time is not a search
  time; the raw rows of this study leave the time columns of such a run empty.

  RUNS KILLED BY THE KERNEL.  33 runs were taken down by the kernel's
  out-of-memory killer: killed by signal 9, nothing on stderr, no time.  The
  runner recorded them as ERROR (rc=-9 in its log) because the driver itself
  said nothing; they are shown here as MEMORY, which is what they are, and the
  raw rows keep the ERROR as written.  They are, by column:
    sml_rbt      24   Dense-n.15.5.gr#0 rep=1, USA-road-t.CTR.gr#0 rep=1, USA-road-t.CTR.gr#5 rep=1, USA-road-t.USA.gr#0 rep=1, USA-road-t.USA.gr#0 rep=2, USA-road-t.USA.gr#0 rep=3, USA-road-t.USA.gr#1 rep=1, USA-road-t.USA.gr#1 rep=2, USA-road-t.USA.gr#1 rep=3, USA-road-t.USA.gr#2 rep=1, USA-road-t.USA.gr#2 rep=2, USA-road-t.USA.gr#2 rep=3, USA-road-t.USA.gr#3 rep=1, USA-road-t.USA.gr#3 rep=2, USA-road-t.USA.gr#3 rep=3, USA-road-t.USA.gr#4 rep=1, USA-road-t.USA.gr#4 rep=2, USA-road-t.USA.gr#4 rep=3, USA-road-t.USA.gr#5 rep=1, USA-road-t.USA.gr#5 rep=2, USA-road-t.USA.gr#5 rep=3, USA-road-t.USA.gr#6 rep=1, USA-road-t.USA.gr#6 rep=2, USA-road-t.USA.gr#6 rep=3
    scala_csr     8   Dense-n.15.0.gr#0 rep=1, Dense-n.15.0.gr#0 rep=2, Dense-n.15.1.gr#0 rep=1, Dense-n.15.2.gr#0 rep=1, Dense-n.15.2.gr#0 rep=2, Dense-n.15.3.gr#0 rep=1, Dense-n.15.5.gr#0 rep=1, Dense-n.15.5.gr#0 rep=2
    scala_rbt     1   Dense-n.15.5.gr#0 rep=1
  All of them sit at sizes where other repeats or instances of the same solver
  died of stack or heap exhaustion in the ordinary way.  A run the machine
  could not hold is the result and was not repeated.

THE CLOCK

  CPU time (user + system), read immediately before the solver call and
  immediately on return, with nothing else between the readings.  cpu_ms in
  the raw rows is that difference and is the only time this zip carries;
  cpu_usr_ms and cpu_sys_ms are its two parts.  Wall time, the whole-process
  clock and the time spent outside the clock were recorded and stay in the
  campaign directories; nothing here is derived from them.

  For OUR NINE EXPORTS the whole verified program is measured.  The entry
  point is handed the graph in plain form and builds its own structures inside
  the call, so that setup is inside the clock: the CSR for *_csr, the array of
  adjacency lists for *_lists (whose duplicate-free insert is quadratic in the
  out-degree), the red-black adjacency map for *_rbt, which is the dominant
  cost and is exactly why it is not hidden.  That is the point of the study: a
  benchmark of generated code has to cover the whole generated program.  The
  *_rbt export takes a cons list of arcs rather than arrays; turning the
  parsed arrays into that list is marshalling and sits outside the clock,
  recorded in the campaign directory's build_ms and not here.

  For the libraries the rule since 2026-10-14 is: a structure that can be
  filled arc by arc while the file is read may be built outside the clock; a
  structure that needs the complete arc list is built after parsing, and
  that build is the first part of the clocked period, the search the second.
  The three library solvers measured both ways are here both ways, and the
  next section says what each column's structure is and where its clock
  opens.

  THE JGRAPHT CLOCK differs between the two JGraphT columns.  jgrapht_csr is
  the solver thread's CPU clock plus the collector's pause time, read from
  the JVM's own counter: under the serial collector the collector runs on
  the VM thread while the measured thread waits, so a thread clock alone
  drops that work.  The process clock was rejected because it counts the JIT
  compiler threads, which keep compiling inside the window.  Before the clock
  opens that driver warms the JIT on the instance itself (on an induced
  subgraph of it above 2^18 arcs), spinning rather than sleeping between
  rounds so that the core is not clocked down when the measurement starts.
  jgrapht_hashgraph, from the first campaign, is on the bare thread clock,
  which drops the collector's work, after a warm-up on a synthetic graph.
  THE SCALA EXPORTS are on the bare thread clock of the first campaign too,
  which understates their collector work; they are context, not the claim.

THE DATA STRUCTURES, COLUMN BY COLUMN

  Every solver walks the same graph; what differs is the structure it walks
  and whether building that structure is inside the clock.

    sml_csr, scala_csr, go_csr
                  CSR arrays (offsets and a packed arc array) built by the
                  exported code from the parser's two arc arrays, plus a
                  cursor array, a stack and a seen array.  INSIDE the clock.
    sml_lists, scala_lists, go_lists
                  an array of adjacency lists, each list kept duplicate-free
                  on insert (quadratic in the out-degree).  INSIDE.
    sml_rbt, scala_rbt, go_rbt
                  red-black trees throughout: the adjacency map and the
                  search state.  INSIDE (the cons list it is handed is built
                  outside; that is marshalling, recorded in results/).
    lemon_csr     LEMON's StaticDigraph: CSR, arcs sorted by tail, built by
                  build() from a complete tail-sorted arc list.  INSIDE: the
                  clock opens on the parsed pair list and covers the counting
                  sort by tail, build(), Dfs's own setup and the search,
                  rebuilt on every repeat.  Campaign of 2026-10-14.
    lemon_linked  LEMON's SmartDigraph: a linked arc list, every arc an
                  entry with next-out and next-in pointers, arcs in file
                  order, filled arc by arc as the file is read.  OUTSIDE:
                  the clock covers Dfs's setup and the search.  First
                  campaign, 2026-10-13.
    jgrapht_csr   jgrapht-opt's SparseIntDirectedGraph: a CSR boolean matrix
                  over integer vertices, constructed from the complete arc
                  list with NO_INCOMING_EDGES (forward arcs only).  INSIDE,
                  rebuilt on every repeat.  Campaign of 2026-10-14.
    jgrapht_hashgraph
                  jgrapht-core's DirectedPseudograph: an object per arc, a
                  hash map from vertex to its edge set and another from
                  edge to its endpoints, filled arc by arc as the file is
                  read.  OUTSIDE: the clock covers the iterator alone.
                  First campaign, 2026-10-13.
    scipy_csr     SciPy's csr_matrix, built by coo_matrix((data, (tails,
                  heads))).tocsr(), a sort-and-pack pass over the complete
                  arc arrays.  INSIDE, rebuilt on every repeat.  Campaign of
                  2026-10-14.
    scipy_prebuilt
                  the same csr_matrix, built once by the same call BEFORE
                  the clock opened; the clock covers depth_first_order
                  alone.  First campaign, 2026-10-13.
    networkx      NetworkX's DiGraph, a dict of dicts, filled arc by arc as
                  the file is read.  OUTSIDE (first campaign only): this is a
                  structure that can genuinely be built while parsing.

  The raw rows of lemon_csr, jgrapht_csr and scipy_csr carry the two parts
  of the one clocked period, clock_build_ms (up to the structure being
  built) and clock_solve_ms (the rest); they add up to cpu_ms and are the
  same two readings with one reading in between, not a second clock.  The
  first-campaign drivers read the clock twice and their rows carry cpu_ms
  alone.  Repacking the parsed arrays into a library's input list is
  marshalling in every column and stays outside.

ONE PROBLEM PER PROCESS

  A search problem is a graph AND a source, so two sources are two problems
  even on one graph.  Each was launched as its own process with its own
  --source; no driver accepts a list of sources.  Repeats got their own
  processes too, so no measurement was taken on a cache an earlier measurement
  had warmed.  The `repeat' column of a raw row is the driver's own count and
  is therefore always 1; which repeat a row is lives in its tag, as rep=k.

  Runs were pinned one per L3 cache island, seven at a time, so no two
  concurrent runs shared any level of cache.  Cores 0-3 were kept free of
  measurement work, in both campaigns.  The solvers were measured in groups,
  a group finishing every family, size and repeat before the next began, so
  a fast solver never shared the machine with a slow one.

THE GRID

  Square-n     n = 1024 .. 2096704, twelve sizes, ten instances each
  Long-n       n = 1024 .. 2097152, twelve sizes, ten instances each
  Dense-n      n = 1024 .. 32768, six sizes, ten instances each
  USA-road-t   twelve road networks, NY (264346 nodes) .. USA (23947347),
               ten sources each
  three repeats of every problem: 420 problems x 13 solvers x 3 = 16380 runs
  in the first campaign, plus 420 x 3 x 3 = 3780 in the campaign of 2026-10-14

  Square-n is a square grid, four arcs per node almost everywhere; Long-n the
  same construction squashed to sixteen rows, so the search runs deep rather
  than wide; Dense-n was built with the challenge's sprand at m = n^2/16, so
  the average degree grows from 64 to 2048 and the work is scanning adjacency
  rather than managing a stack; USA-road-t is twelve real road networks, near
  planar, average degree about 2.4, the only family large enough that memory
  rather than arithmetic decides which solvers can run at all.  The instance
  files are the Dijkstra study's, reached through symbolic links; Dense-n is
  the BFS study's.  The sources are this study's own draw, not the BFS
  study's, and that was checked not to matter: every graph here is fully
  reachable from every vertex, so a full sweep's work is fixed by the graph
  alone (findings_sources/ in the study).

WHERE THE ROWS COME FROM

  Thirteen columns are from the campaign of 2026-10-13 (results/20261013_110953,
  16380 runs planned, all recorded): the nine exports, networkx, and the
  first-campaign library columns lemon_linked, jgrapht_hashgraph and
  scipy_prebuilt.  Three are from the campaign of 2026-10-14
  (results/20261014_114618): lemon_csr, jgrapht_csr and scipy_csr, the same three
  libraries measured on the same problems, same sources, same cap and
  pinning, with CSR built inside the clock.  Each column's conditions.txt is
  the flags.txt of the directory its rows came from.  COLUMNS.txt lists it
  per column.

THE SIXTEEN COLUMNS

  ours, from three code exports of the same verified algorithm -- over CSR
  arrays (_csr), over an array of adjacency lists (_lists) and over red-black
  trees (_rbt) -- each compiled to three languages:
    sml_csr           the array export, Standard ML (MLton 20241230, -inline 10000)
    sml_lists         the adjacency-list export, Standard ML (MLton 20241230, -inline 10000)
    sml_rbt           the red-black-tree export, Standard ML (MLton 20241230, -inline 10000)
    scala_csr         the array export, Scala 3.3.8 on JDK 21.0.12, serial GC, -Xmx45g, bare thread CPU clock
    scala_lists       the adjacency-list export, Scala 3.3.8 on JDK 21.0.12, serial GC, -Xmx45g, bare thread CPU clock
    scala_rbt         the red-black-tree export, Scala 3.3.8 on JDK 21.0.12, serial GC, -Xmx45g, bare thread CPU clock
    go_csr            the array export, Go, stack raised to the runtime maximum (1 GB)
    go_lists          the adjacency-list export, Go, stack raised to the runtime maximum (1 GB)
    go_rbt            the red-black-tree export, Go, stack raised to the runtime maximum (1 GB), built through an overlay because the upload has two unused imports

  library implementations, for context; the three measured twice are
  listed as two solvers each:
    lemon_csr         LEMON 1.3.1 Dfs<StaticDigraph>: LEMON's CSR, built INSIDE the clock from the tail-sorted arc list, rebuilt every repeat; Dfs::run(s), no early exit; g++ 11.4.0 -O3 -march=native -DNDEBUG; 2026-10-14
    lemon_linked      LEMON 1.3.1 Dfs<SmartDigraph>: a linked arc list (arcs in file order, next-arc pointers), built OUTSIDE the clock; Dfs::run(s), no early exit; g++ 11.4.0 -O2 -DNDEBUG; 2026-10-13
    jgrapht_csr       JGraphT 1.5.3 DepthFirstIterator on jgrapht-opt's SparseIntDirectedGraph: CSR, built INSIDE the clock, rebuilt every repeat; drained to exhaustion, cross-component traversal off; JDK 21.0.12, serial GC, -Xmx45g; clock = thread CPU + collector time; warmed up on the instance itself; 2026-10-14
    jgrapht_hashgraph JGraphT 1.5.3 DepthFirstIterator on DirectedPseudograph: an object per arc with hash maps from vertex to edge set and from edge to endpoints, built OUTSIDE the clock; drained to exhaustion, cross-component traversal off; JDK 21.0.12, serial GC, -Xmx45g; bare thread CPU clock; warmed up on a synthetic graph; 2026-10-13
    scipy_csr         scipy 1.15.3 sparse.csgraph.depth_first_order (Cython) on a CSR matrix built INSIDE the clock by coo_matrix(...).tocsr(), rebuilt every repeat; 2026-10-14
    scipy_prebuilt    scipy 1.15.3 sparse.csgraph.depth_first_order (Cython) on the same CSR matrix, built by coo_matrix(...).tocsr() BEFORE the clock opened, once per process; 2026-10-13
    networkx          networkx 3.4.2 dfs_predecessors (pure Python), DiGraph (dict of dicts) filled while the file is read, outside the clock; 2026-10-13

Built 2026-10-15 01:03 from 20261013_110953, 20261014_114618 by bench/build_results_zip.py.
results/ holds the raw data; this holds only the tables.
