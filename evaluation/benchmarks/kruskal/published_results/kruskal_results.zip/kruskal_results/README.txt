Kruskal study -- headline timings
=================================

Seven columns on three minimum-spanning-tree families: two grid families of
the 9th DIMACS Implementation Challenge on shortest paths and a dense family
built for the BFS study with the challenge's own generator.  Seven solvers:
one verified Isabelle export, Kruskal_Imperative_Min, built in three
languages, and four libraries' Kruskal.  One directory per column, one CSV
per family:

    <column>/Square-n.csv
    <column>/Long-n.csv
    <column>/Dense-n.csv
    <column>/conditions.txt    machine, pinning, clock and cap, exactly as
                               the campaign recorded them at its start
    <column>/raw/              the unaggregated driver rows these tables
                               were built from
    COLUMNS.txt                which column comes from which directory and
                               which source file
    AGREEMENT.txt              the cross-check of the tree weights

CSV SHAPE

    nodes,s1,...,s10,finished,average_ms

  One row per problem size.  Every family puts TEN INSTANCES at each size,
  so s1..s10 are the ten instances; a column is one minimum spanning tree
  problem.  finished says how many of the ten produced a time.  average_ms,
  the last column, is the average over those.

  Each cell is the MEDIAN of that problem's three repeats, in milliseconds.
  Median within a problem, mean across problems: the convention used
  throughout these studies.

THE RAW ROWS

    instance,nodes,arcs,edges,repeat,status,tree_edges,tree_weight,
    cpu_ms,cpu_usr_ms,cpu_sys_ms,[clock_build_ms,clock_solve_ms,]
    tag,inferred_from,core

  One row per run, as the driver printed it and the runner appended it,
  stripped to the clocked period.  cpu_ms is THE time: the difference
  between the two canonical CPU-clock readings.  cpu_usr_ms and cpu_sys_ms
  are its user and system halves (for the two JVM columns the collector's
  time is counted in the user half).  clock_build_ms and clock_solve_ms
  appear in the scipy rows only: the two parts of that same period from one
  intermediate reading, taken after the matrix is built and before the
  solve, and they add up to cpu_ms.  The columns that are not that period
  -- the whole-process clock, the wall clock, and the parse, collapse and
  input-array work outside the clock -- are left out here and stay in the
  campaign directory.

  THE repeat COLUMN READS 1 ON EVERY MEASURED ROW.  Each repeat was its own
  process (see ONE PROBLEM PER PROCESS), so each driver counted one repeat.
  The repeat number of a run is in its tag: Long-n;rep=2;warmcore=3s is the
  second repeat.  Rows the runner wrote itself, because the driver was
  killed before it printed (TIMEOUT) or was never launched
  (TIMEOUT_INFERRED), have the repeat column empty; an inferred row names
  the instance it follows from in inferred_from.  core is the CPU core the
  run was pinned to.

  arcs is the file's arc count, edges the count after parallel edges were
  collapsed (see THE PROBLEM).  tree_edges and tree_weight are the answer.

ONLY VALID MEASUREMENTS ARE TIMES

  A cell carries a number only where the run finished and the driver
  confirmed the returned edges form a spanning forest of the right size.
  Everything else is a word, never a number:

  TIMEOUT means the solver did not finish inside the 1200 s cap.  MEMORY means
  it ran out of memory -- address space, heap or stack, which for the export
  is the same event seen from several sides.  Where a smaller size in the
  same family already failed, the larger sizes were not run at all: a solver
  that cannot do n is not going to do 2n.  Those carry the same word.
  average_ms then covers only the problems that did finish, so two rows are
  comparable only when both say finished = 10.

  RUNS KILLED BY THE KERNEL.  0 runs were taken down by the kernel's
  out-of-memory killer (killed by signal 9, nothing on stderr, no time; the
  runner records those as ERROR with rc=-9, and this archive would show them
  as MEMORY).

  THE 6300 ROWS BY STATUS, as counted from the campaign's CSVs when this
  archive was built:
    SOLVED              5637
    TIMEOUT_INFERRED     611
    TIMEOUT               52

  No run was a BAD_TREE, none ran out of memory, none failed for another
  reason.  Every word in the tables is a timeout or follows from one.

WHERE EACH LADDER STOPPED, read off the rows:
    sml       Square-n  every size finished, up to n = 2096704
    sml       Long-n    every size finished, up to n = 2097152
    sml       Dense-n   every size finished, up to n = 32768
    scala     Square-n  finished through n = 131044; at n = 262144 the 30 runs are 10 TIMEOUT, 20 TIMEOUT_INFERRED; the 3 larger size(s) were not run
    scala     Long-n    finished through n = 131072; at n = 262144 the 30 runs are 3 SOLVED, 10 TIMEOUT, 17 TIMEOUT_INFERRED; the 3 larger size(s) were not run
    scala     Dense-n   finished through n = 2048; at n = 4096 the 30 runs are 10 TIMEOUT, 20 TIMEOUT_INFERRED; the 3 larger size(s) were not run
    go        Square-n  finished through n = 131044; at n = 262144 the 30 runs are 24 SOLVED, 2 TIMEOUT, 4 TIMEOUT_INFERRED; the 3 larger size(s) were not run
    go        Long-n    finished through n = 262144; at n = 524288 the 30 runs are 10 TIMEOUT, 20 TIMEOUT_INFERRED; the 2 larger size(s) were not run
    go        Dense-n   finished through n = 2048; at n = 4096 the 30 runs are 10 TIMEOUT, 20 TIMEOUT_INFERRED; the 3 larger size(s) were not run
    lemon     Square-n  every size finished, up to n = 2096704
    lemon     Long-n    every size finished, up to n = 2097152
    lemon     Dense-n   every size finished, up to n = 32768
    jgrapht   Square-n  every size finished, up to n = 2096704
    jgrapht   Long-n    every size finished, up to n = 2097152
    jgrapht   Dense-n   every size finished, up to n = 32768
    scipy     Square-n  every size finished, up to n = 2096704
    scipy     Long-n    every size finished, up to n = 2097152
    scipy     Dense-n   every size finished, up to n = 32768
    networkx  Square-n  every size finished, up to n = 2096704
    networkx  Long-n    every size finished, up to n = 2097152
    networkx  Dense-n   every size finished, up to n = 32768

THE PROBLEM

  A minimum spanning forest of the whole graph.  The instances are the
  shortest-path challenge's directed files; every arc line (u, v, w) is one
  undirected edge {u, v} of weight w.  The grids carry both directions of
  every pair with different weights and the dense files carry a few per
  cent of their arcs twice; EVERY DRIVER'S PARSER COLLAPSES EACH UNORDERED
  PAIR TO ITS CHEAPEST EDGE before the clock, so all seven solvers get the same simple graph: each edge
  once as (lo, hi, w), in (lo, hi) order.  In the five compiled drivers the
  collapse is two stable counting sorts of the edge indices (by the larger
  endpoint, then by the smaller) and one scan keeping the minimum weight of
  each run, linear in n + m; the two Python drivers do the same with one
  stable numpy argsort of the packed key lo * n + hi and a
  minimum.reduceat.  The time of the collapse is in results/, in dedup_ms.
  SciPy's weights additionally go in shifted up by one, so that its
  zero-weight tree edges are not dropped from the returned tree; the shift
  is taken off after the clock.

  Node ids are handed to the export exactly as the file writes them, 1..n,
  with the vertex count nodes + 1 so that they index its union-find array
  directly (index 0 is an unused singleton).  The library drivers renumber
  to 0..n-1 while parsing, which is what those libraries index from.

THE CROSS-CHECK

  The weight of a minimum spanning forest is a property of the graph alone.
  Every raw row carries tree_edges and tree_weight, and this archive was not
  built until every instance had ONE answer across all the columns that
  finished it; AGREEMENT.txt says how many instances and columns that
  covered.  Each driver also checked its own answer after the clock: a
  union-find pass over the returned edges (no edge may close a cycle), and
  the count against n minus the number of connected components of the whole
  graph, found by a second union-find pass over every edge (the Python
  drivers use scipy's connected_components for that count).  LEMON's and
  JGraphT's drivers also compare the weight they re-sum with the total the
  library returned.

THE CLOCK

  Every time in this archive is one quantity and one only: the difference
  between two readings of the CPU clock, taken immediately before the solver
  call and immediately on return.  For the five native processes it is
  getrusage(RUSAGE_SELF) over the process, user plus system: MLton's
  Timer.startCPUTimer / checkCPUTimer in SML, syscall.Getrusage in Go,
  getrusage(2) in C++, resource.getrusage in Python.  For the two JVM
  solvers it is the solver thread's CPU time (ThreadMXBean
  .getCurrentThreadCpuTime) PLUS the collector's accumulated time (the sum
  of GarbageCollectorMXBean.getCollectionTime over the collectors, in whole
  milliseconds), both read before and after the call and the differences
  added, with the serial collector and one processor: a collection happens
  only because the measured thread allocated and only while that thread
  waits.  The earlier studies' Scala exports were on the bare thread clock,
  which understates; this study uses the corrected clock for both JVM
  solvers from the start.  The Go clock counts every thread of the process,
  so Go's own collector is in it too.

  For THE EXPORT, in all three languages, the whole verified program lies
  between the two readings: kruskal_imp_min negates and copies the costs,
  sorts the edge index array with its own quicksort, initialises its
  union-find array and runs the loop.  Its three input arrays -- the
  parser's arrays repacked into the shape the signature asks for -- are
  built outside and recorded in results/ (build_ms), fresh for every
  repeat because the export sorts the index array in place.  The closure
  the export returns is built before the first reading and applied between
  the readings.

  THE LIBRARIES are held to one rule, the same as in the earlier studies: a
  structure that can be filled while the file is read may be built outside
  the two readings; a structure that needs the complete arc list first is
  built after parsing, in a pass of its own, and that build is the first
  part of the measured period.  Kruskal's algorithm needs no adjacency
  structure, so each library was given the representation most suitable
  for reading its edges off, and the rule was applied to it.  The section
  HOW EACH COLUMN WAS OBTAINED says, per column, what is inside.

  Both JVM drivers warm the JIT on the instance itself before the clock
  opens, spinning rather than sleeping between rounds, and call System.gc()
  before each clocked repeat, outside the clock.  EVERY RUN STARTED ON A
  WARM CORE: the runner spun three seconds on the run's core and then
  exec'd the driver on it, outside the driver's process and outside every
  clock it reads (the tag says warmcore=3s).  An idle core on this box is
  parked at 1.5 GHz and a short run that starts cold reads up to twice slow.

THE SCALA AND GO BUILDS OF THE EXPORT ARE QUADRATIC

  kruskal_imp_min turns the cost array into a list and back (freeze, then
  of_list).  In the Scala and Go targets of_list indexes the cons list once
  per element, walking it from the head each time, so that step is
  quadratic in the edge count; the SML build's of_list is Array.fromList
  and is linear.  The two ladders stop where that step passes the cap (see
  WHERE EACH LADDER STOPPED).  That is a property of the export as uploaded
  and nothing was changed: the whole generated program is what is measured.

ONE PROBLEM PER PROCESS

  Each instance was launched as its own process, and so was each repeat, so
  no measurement was taken on a cache an earlier measurement had warmed.
  Runs were pinned one per L3 cache island, so no two concurrent runs shared
  any level of cache.  Cores 0-3 were kept free of measurement work.  The
  solvers were measured in groups, a group finishing every family, size and
  repeat before the next began: sml first, then the four libraries, then
  scala and go.

HOW THE CAMPAIGN RAN

  The runner is bench/run_campaign.py.  For every (solver, instance, repeat)
  it launched one process on one core:

    taskset -c <core> timeout -k 10 1200 \
        .venv/bin/python bench/warm_then_exec.py 3 -- \
        <driver> --tag "<family>;rep=<k>;warmcore=3s" <instance.gr>

  warm_then_exec.py narrows the affinity to the single core it is on, spins
  for 3 s in a busy loop, then execs the driver on that core.  timeout
  sends SIGTERM at 1200 s and SIGKILL 10 s later; a killed run is recorded
  TIMEOUT with every time column empty.  The driver prints one CSV row on
  stdout; the runner checks it has the expected columns, appends
  inferred_from and core, and writes it to <solver>/<family>.csv.  A
  timeout stops the ladder: the remaining repeats of that instance and
  every larger size of that (solver, family) are written TIMEOUT_INFERRED
  without being run, inferred_from naming the instance that timed out.
  Seven workers, one per L3 island, on cores 4, 8, 12, 16, 20, 24 and 28;
  the eighth island (cores 0-3) was reserved.  The Python drivers ran with
  --mem-gb 45, an RLIMIT_AS of 45 GiB; the JVMs with -Xmx45g; the SML, Go
  and C++ processes uncapped.  A watchdog (bench/watch_campaign.sh, polling
  every 60 s) would have restarted the runner had it died; it never did.

  Timeline, from the campaign log (local time, 2026-10-15):
    09:13:44  campaign 20261015_091344: 6300 runs, 7 solvers, 7 workers on cores [4, 8, 12, 16, 20, 24, 28], cap 1200s
    09:13:44  -- phase: sml
    09:26:35  -- phase done: sml  (900 of 6300 runs recorded)
    09:26:35  -- phase: lemon, jgrapht, scipy, networkx
    12:48:53  -- phase done: lemon, jgrapht, scipy, networkx  (4500 of 6300 runs recorded)
    12:48:53  -- phase: scala, go
    13:56:48  -- go Dense-n: stopping the ladder at n=4096 (Dense-n.12.0.gr timed out)
    14:24:25  -- scala Dense-n: stopping the ladder at n=4096 (Dense-n.12.0.gr timed out)
    16:13:08  -- scala Square-n: stopping the ladder at n=262144 (Square-n.18.0.gr timed out)
    17:14:25  -- go Square-n: stopping the ladder at n=262144 (Square-n.18.7.gr timed out)
    18:29:59  -- scala Long-n: stopping the ladder at n=262144 (Long-n.18.0.gr timed out)
    18:56:03  -- go Long-n: stopping the ladder at n=524288 (Long-n.19.0.gr timed out)
    18:56:03  -- phase done: scala, go  (6300 of 6300 runs recorded)
    18:56:03  done: 6300 rows in results/20261015_091344
  watchdog.log, whole:
    09:13:59  watching /home/thomas/kruskal/results/20261015_091344 (poll 60s, at most 20 restarts)
    18:56:13  finished: 6300 of 6300 runs recorded

THE MACHINE, as read when this archive was built:
  Model name           AMD EPYC 7343 16-Core Processor
  CPU(s)               32
  Thread(s) per core   1
  Socket(s)            2
  NUMA node(s)         2
  L1d cache            1 MiB (32 instances)
  L2 cache             16 MiB (32 instances)
  L3 cache             256 MiB (8 instances)
  memory               377 GiB, no swap
  kernel               5.15.0-198-generic
  os                   Ubuntu 22.04.4 LTS
  cpufreq governor     schedutil (an idle core parks at about 1.5 GHz)

HOW EACH COLUMN WAS OBTAINED

  Every build line is bench/build_all.sh, every launch line is the driver's
  run.sh or the runner's command above; they are quoted here from those
  files.  Each driver reads the whole .gr file, collapses parallel edges,
  counts the graph's components for the check, and then measures.

  sml -- drivers/sml/main.sml, gr_parser.sml, solve_sml.mlb
    build     mlton -inline 10000 -output solve_sml solve_sml.mlb
              (mlton-20241230; native amd64 code generator, no other flag; the
              .mlb lists the basis library, the export, the reader and the
              driver).  The export file Kruskal_Imperative_Min.sml is a
              symbolic link to the upload's .SML file: MLton accepts only
              the lower-case extension and the upload is kept as received.
    entry     Kruskal_Imp_Min.kruskal_imp_min costs eps edges (nodes + 1),
              costs an array of the export's rat built with rat_of_int, eps
              an (int * int) array of endpoints, edges the identity index
              array; the returned closure is applied inside the clock and
              yields the tree's edge indices as a list.
    clock     Timer.startCPUTimer before the call, Timer.checkCPUTimer on
              return (user + system of the process); Time.now beside it for
              the wall clock, which is not used.

  scala -- drivers/scala/Driver.scala, run.sh
    build     scalac -d classes generated/Kruskal_Scala/Kruskal_Imperative_Min.scala Driver.scala
              (Scala compiler version 3.3.8; no compiler flag).
    launch    java -Xmx45g -XX:ActiveProcessorCount=1 -XX:+UseSerialGC
              -cp classes:scala3-library_3-3.3.8.jar:scala-library-2.13.18.jar Driver
              on Eclipse Adoptium Temurin-21.0.12.1+1 (JAVA_VERSION 21.0.12.1, 2026-08-18).
              The solve runs on a thread of its own with a 24 GiB stack
              (24576 MB; the export recurses through its Heap monad once per
              edge and the JVM eliminates no tail calls).
    entry     Kruskal_Imp_Min.kruskal_imp_min(costs, eps, edges, n)(()) with
              the arrays made by the export's Array.init / Array.LongT and
              costs by rat_of_int(Machine.int(w)); n = nodes + 1.
    warm-up   the measured call on the instance itself, on its induced
              subgraph on the first 2^k vertices when the instance has more
              than 2^14 edges (the quadratic of_list makes a larger round
              take minutes), repeated until CompilationMXBean's total
              compilation time has crept 4 ms or less in two consecutive
              rounds and at least 2 s of rounds have run (at most 200 rounds
              or 60 s); a yielding spin while the compiler settles.
    clock     thread CPU (ThreadMXBean.getCurrentThreadCpuTime) plus
              collector time (GarbageCollectorMXBean.getCollectionTime,
              summed); cpu_usr_ms = thread user time + collector time,
              cpu_sys_ms = thread CPU - thread user.

  go -- drivers/go/main.go, gr.go, go.mod
    build     go build -o solve_go .   (go version go1.27.2 linux/amd64; no flag, default
              optimisation).  go.mod declares `go 1.18' and reaches the
              export with  replace isabelle/exported => ../../generated/Kruskal_Go,
              so the binary holds the uploaded code without a copy.
    launch    solve_go --tag <tag> <instance>.  debug.SetMaxStack(2000 MB)
              raises the goroutine stack limit; a stack overflow would be
              recorded MEMORY (none occurred).
    entry     Kruskal_Imp_Min.Kruskal_imp_min(costs []Rat, eps []Prod[int64,
              int64], edges []int64, n int64), costs by Rat_of_int; the
              returned func is called inside the clock and yields a
              List[int64] of edge indices.
    clock     syscall.Getrusage(RUSAGE_SELF), user + system, whole process.

  lemon -- drivers/cpp/solve_lemon_kruskal.cc
    build     g++ -O3 -march=native -DNDEBUG -I<lemon>/include
              -o solve_lemon_kruskal solve_lemon_kruskal.cc -L<lemon>/lib -lemon
              (g++ (Ubuntu 11.4.0-1ubuntu1~22.04.3) 11.4.0).  LEMON 1.3.1 from lemon-1.3.1.tar.gz, built
              with CMake as a Release build, -O3 -DNDEBUG, compiler /usr/bin/c++; kruskal() itself is
              header-only (lemon/kruskal.h).
    structure SmartGraph with reserveNode/reserveEdge, n addNode calls,
              one addEdge(nodeFromId(u - 1), nodeFromId(v - 1)) per edge,
              and an EdgeMap<int64_t> of costs.  OUTSIDE the clock.
    entry     kruskal(g, cost, tree) with a fresh EdgeMap<bool> tree
              constructed inside the clock.  Inside the library (read from
              lemon/kruskal.h): a std::vector<std::pair<Edge, Value>> of
              every edge with its cost, std::sort of that vector by cost,
              a UnionFind over a NodeMap, and the loop setting the output
              map; it returns the total weight.
    clock     getrusage(RUSAGE_SELF), user + system.

  jgrapht -- drivers/java/JGraphTKruskal.java, run.sh
    build     javac -cp jgrapht-core-1.5.3.jar:jheaps-0.14.jar -d classes JGraphTKruskal.java
              with the JDK below; no flag.
    launch    java -Xmx45g -XX:ActiveProcessorCount=1 -XX:+UseSerialGC
              -cp classes:jgrapht-core-1.5.3.jar:jheaps-0.14.jar JGraphTKruskal
              on Eclipse Adoptium Temurin-21.0.12.1+1 (JAVA_VERSION 21.0.12.1, 2026-08-18).
              jheaps is jgrapht-core's dependency and is on the classpath;
              Kruskal does not use it.  jgrapht-opt is NOT
              used (its CSR graph would be built inside the clock for an
              incidence index Kruskal never reads).
    structure org.jgrapht.graph.DefaultUndirectedWeightedGraph<Integer,
              DefaultWeightedEdge>: addVertex for 0..n-1, then addEdge and
              setEdgeWeight((double) w) per edge.  OUTSIDE the clock.
    entry     new org.jgrapht.alg.spanning.KruskalMinimumSpanningTree<>(g)
              .getSpanningTree().  Inside the library (read from
              jgrapht-core-1.5.3-sources.jar): a UnionFind over vertexSet(),
              an ArrayList copy of edgeSet() sorted with
              Comparator.comparingDouble(graph::getEdgeWeight), the loop,
              and a HashSet of the tree edges.
    warm-up   as for scala, with the budget 2^18 edges (a separate graph of
              the induced subgraph above that).
    clock     as for scala.

  scipy -- bench/scipy_kruskal.py, gr_read.py
    runtime   Python 3.10.12 in .venv; scipy 1.15.3, numpy 2.2.6, networkx 3.4.2.  OMP_NUM_THREADS and the other
              thread-count variables set to 1; RLIMIT_AS 45 GiB.
    parse     gr_read.parse_gr splits the whole byte buffer with numpy;
              collapse_min (above); then, outside the clock, the input
              arrays data = (w + 1) as float64 and indices = hi as int32.
    inside    indptr = cumsum(bincount(lo, minlength=n)) as int64, then
              scipy.sparse.csr_matrix((data, indices, indptr), shape=(n, n))
              -- the intermediate reading -- then
              scipy.sparse.csgraph.minimum_spanning_tree(graph), whose
              documentation says it is computed with Kruskal's algorithm
              and which converts its input to CSR (already CSR here).  The
              matrix holds each edge once at (lo, hi); the library reads
              graph[u, v] and graph[v, u] as one undirected edge.  Rebuilt
              every repeat.
    clock     resource.getrusage(RUSAGE_SELF), user + system; the two parts
              in clock_build_ms and clock_solve_ms.
    after     tree.nnz edges, weight tree.sum() minus the shift, forest and
              count checked with connected_components.

  networkx -- bench/networkx_kruskal.py, gr_read.py
    runtime   as for scipy.
    structure networkx.Graph(): add_nodes_from(range(n)), then
              add_weighted_edges_from over the collapsed (lo, hi, w) triples.
              OUTSIDE the clock.
    inside    list(networkx.minimum_spanning_edges(G, algorithm="kruskal",
              weight="weight", data=True)): the generator is drained, and
              draining it is the algorithm.  Inside the library
              (networkx/algorithms/tree/mst.py, kruskal_mst_edges): every
              edge collected as a (weight, u, v, data) tuple, sorted with
              Python's sorted on the weight, and joined in
              networkx.utils.UnionFind.
    clock     resource.getrusage(RUSAGE_SELF), user + system.

THE GRID

  Square-n     n = 1024 .. 2096704, twelve sizes, ten instances each
  Long-n       n = 1024 .. 2097152, twelve sizes, ten instances each
  Dense-n      n = 1024 .. 32768, six sizes, ten instances each
  three repeats of every problem; 300 problems, 6300 runs

  The same files as the BFS and DFS studies, through symbolic links
  (instances/Square-n and Long-n to the Dijkstra study's, Dense-n to the
  BFS study's).  Square-n and Long-n were generated with the challenge's
  own spgrid (ch9-1.1, gens/grid/spgrid.c) through its genSquare-n.gr.pl
  and genLong-n.gr.pl scripts changed only to make ten graphs per size;
  Square-n is a square grid with very nearly 4n arcs, Long-n the same
  construction squashed to sixteen rows.  Dense-n was generated with the
  challenge's sprand (gens/rand/sprand.c) at m = n^2/16, from 64 arcs per
  node at n = 1024 to 2048 at n = 32768, the ladder stopping at 2^15
  because the arc count squares.  Each file's first line is the
  generator's own record of its parameters and seed.  The road networks
  are left out: one network per size cannot give ten instances per size.
  GENERATORS.txt, kept beside the study directories, records the generator
  sources and their checksums.

THE EXPORT, AS MEASURED

  generated/ is the upload kruskal_code.zip unpacked, read-only, and
  generated/MD5SUM.txt pins every file.  When this archive was built every
  file in it matched that list:
    f607fc340bc6fdcc057f677d4d39e89b  ./Kruskal_Go/Heap/exported.go                 OK
    25934c326f28f9f556297f235805073d  ./Kruskal_Go/Kruskal_Imp_Min/exported.go      OK
    e160ca262785dbb7e68452559c64935c  ./Kruskal_Go/Machine/exported.go              OK
    b64ca2fd3746cd0117b47c64680fd6bd  ./Kruskal_Go/go.mod                           OK
    7fe620ba321c4bba8e6d7bae5dad15c6  ./Kruskal_SML/Kruskal_Imperative_Min.SML      OK
    d4edb346d6c44680e753c0e62af44367  ./Kruskal_Scala/Kruskal_Imperative_Min.scala  OK

  Checksums of the upload and the libraries linked or loaded:
    95c71bead47a3bb7b4ba2842607b91b1  kruskal_code.zip
    f73efc783603c57d8e8e53c90af21e88  java/lib/jgrapht-core-1.5.3.jar
    53dfa9f277efd1d392148eb607d9b4a6  java/lib/jheaps-0.14.jar
    7173df3f675c6860fb24ba5b5b65fefa  reference/lemon-install/lib/libemon.a
    4483d259166cd13d9a7b4fa74b8c1ce6  toolchains/scala3-3.3.8/lib/scala3-library_3-3.3.8.jar
    4825bad81cee169fed825dc2f98a7d41  toolchains/scala3-3.3.8/lib/scala-library-2.13.18.jar


WAS THIS WHAT RAN?

  Every binary, class file, driver and export file on disk was last
  modified before the campaign started at 2026-10-15 09:13:44, and none since:
    the SML binary             drivers/sml/solve_sml                                   2026-10-15 09:12:42   before the start
    the Scala driver class     drivers/scala/classes/Driver.class                      2026-10-15 09:12:48   before the start
    the Scala export class     drivers/scala/classes/Kruskal_Imp_Min.class             2026-10-15 09:12:48   before the start
    the Go binary              drivers/go/solve_go                                     2026-10-15 09:12:48   before the start
    the LEMON binary           drivers/cpp/solve_lemon_kruskal                         2026-10-15 09:12:51   before the start
    the JGraphT driver class   drivers/java/classes/JGraphTKruskal.class               2026-10-15 09:12:52   before the start
    the SciPy driver           bench/scipy_kruskal.py                                  2026-10-15 09:12:31   before the start
    the NetworkX driver        bench/networkx_kruskal.py                               2026-10-15 03:12:50   before the start
    the Python reader          bench/gr_read.py                                        2026-10-15 03:12:50   before the start
    the campaign runner        bench/run_campaign.py                                   2026-10-15 03:13:21   before the start
    the core warmer            bench/warm_then_exec.py                                 2026-10-15 02:46:55   before the start
    the SML export             generated/Kruskal_SML/Kruskal_Imperative_Min.SML        2026-10-15 02:43:38   before the start
    the Scala export           generated/Kruskal_Scala/Kruskal_Imperative_Min.scala    2026-10-15 02:43:38   before the start
    the Go export              generated/Kruskal_Go/Kruskal_Imp_Min/exported.go        2026-10-15 02:43:38   before the start
    the upload                 kruskal_code.zip                                        2026-10-15 02:33:52   before the start

  bench/build_all.sh rebuilt all five compiled drivers from scratch at
  09:12 on the day; the SciPy driver (bench/scipy_kruskal.py) builds the matrix
  directly as csr_matrix((data, indices, indptr)) from the parser's
  (lo, hi)-sorted edges, inside the clock, rebuilt on every repeat.

THE SEVEN COLUMNS

  ours, one verified export compiled to three languages:
    sml        the export in Standard ML; MLton 20241230, -inline 10000; getrusage clock
    scala      the export in Scala 3.3.8 on JDK 21.0.12.1, -Xmx45g, one processor, serial collector, 24 GiB solve-thread stack; clock = thread CPU + collector time; warmed up on the instance itself
    go         the export in Go 1.27.2, goroutine stack limit raised to 2000 MB; getrusage clock

  library implementations, for context:
    lemon      LEMON 1.3.1 kruskal(g, cost, tree) on SmartGraph + EdgeMap<int64_t>, filled edge by edge OUTSIDE the clock; inside: the (edge, cost) vector, std::sort, UnionFind, the output map; g++ 11.4.0 -O3 -march=native -DNDEBUG
    jgrapht    JGraphT 1.5.3 KruskalMinimumSpanningTree on DefaultUndirectedWeightedGraph<Integer, DefaultWeightedEdge>, filled edge by edge OUTSIDE the clock; inside: the edge list copy, its sort, UnionFind; JDK 21.0.12.1, -Xmx45g, one processor, serial collector; clock = thread CPU + collector time; warmed up on the instance itself
    scipy      scipy 1.15.3 sparse.csgraph.minimum_spanning_tree (Kruskal, Cython) on a csr_matrix built INSIDE the clock as csr_matrix((data, indices, indptr)) from the (lo, hi)-sorted edge list, a bincount and a cumulative sum, rebuilt every repeat; weights shifted up by one before the clock
    networkx   networkx 3.4.2 minimum_spanning_edges(algorithm='kruskal'), pure Python, drained, on a Graph filled edge by edge OUTSIDE the clock

Built 2026-10-15 19:18 by bench/build_results_zip.py from results/20261015_091344.
results/ holds the raw data; this holds the tables and, under raw/,
the driver rows stripped to the clocked period.
