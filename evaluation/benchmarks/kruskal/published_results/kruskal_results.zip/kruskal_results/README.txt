Kruskal study -- the published tables and raw rows (Tables 16 to 18)
====================================================================

One directory per column, one CSV per family:

    <column>/Square-n.csv, Long-n.csv, Dense-n.csv
    <column>/conditions.txt    machine, pinning, clock and cap, as the campaign
                               recorded them at its start
    <column>/raw/<family>.csv  the driver rows the tables were built from
    COLUMNS.txt                which column comes from which results directory
                               and which source file
    AGREEMENT.txt              the cross-check of the tree weights

CSV SHAPE

    nodes,s1,...,s10,finished,average_ms

  One row per problem size; every family puts ten instances at each size
  (s1..s10).  Each cell is the median of that problem's three repeats, in
  milliseconds; finished says how many of the ten produced a time; average_ms
  is the mean over those.

THE RAW ROWS

    instance,nodes,arcs,edges,repeat,status,tree_edges,tree_weight,
    cpu_ms,cpu_usr_ms,cpu_sys_ms,[clock_build_ms,clock_solve_ms,]
    tag,inferred_from,core

  One row per run, stripped to the clocked period.  cpu_ms is the time: the
  difference between the two CPU-clock readings; cpu_usr_ms and cpu_sys_ms are
  its user and system halves (for the two JVM columns the collector's time is
  counted in the user half).  clock_build_ms and clock_solve_ms appear in the
  scipy rows only: the two parts of that period from one intermediate reading
  after the matrix is built; they add up to cpu_ms.  The repeat column reads 1
  on every measured row (each repeat was its own process); the repeat number is
  in the tag (Long-n;rep=2;warmcore=3s).  Rows the runner wrote itself, because
  the driver was killed before it printed (TIMEOUT) or never launched
  (TIMEOUT_INFERRED), have the repeat column empty; an inferred row names the
  instance it follows from in inferred_from.  core is the CPU core the run was
  pinned to.  arcs is the file's arc count, edges the count after parallel
  edges were collapsed; tree_edges and tree_weight are the answer.

ONLY VALID MEASUREMENTS ARE TIMES

  A cell carries a number only where the run finished and the driver confirmed
  the returned edges form a spanning forest of the right size.  TIMEOUT means
  the solver did not finish inside the 1200 s cap; where a smaller size of the
  same family already timed out, the larger sizes were not run and carry the
  same word.  Of the 6300 rows, 5637 are SOLVED, 52 TIMEOUT and 611
  TIMEOUT_INFERRED; no run ran out of memory or failed otherwise.

  Where each ladder stopped: sml, lemon, jgrapht, scipy and networkx finished
  every size of every family; scala and go finished Square-n through
  n = 131044, Long-n through n = 131072 (scala) and 262144 (go), and Dense-n
  through n = 2048.

THE PROBLEM

  A minimum spanning forest of the whole graph.  The instances are the
  shortest-path challenge's directed files; every arc line (u, v, w) is one
  undirected edge {u, v} of weight w.  The grids carry both directions of every
  pair with different weights and the dense files carry a few per cent of their
  arcs twice; every driver's parser collapses each unordered pair to its
  cheapest edge before the clock, so all seven solvers get the same simple
  graph, each edge once as (lo, hi, w) in (lo, hi) order (two stable counting
  sorts and a scan in the compiled drivers; one stable numpy argsort and a
  minimum.reduceat in the Python drivers).  SciPy's weights go in shifted up by
  one, so that its zero-weight tree edges are not dropped from the returned
  tree; the shift is taken off after the clock.  Node ids are handed to the
  export as the file writes them, 1..n, with the vertex count nodes + 1; the
  library drivers renumber to 0..n-1 while parsing.

THE CROSS-CHECK

  The weight of a minimum spanning forest is a property of the graph alone.
  Every raw row carries tree_edges and tree_weight, and every instance has one
  answer across all the columns that finished it (AGREEMENT.txt).  Each driver
  also checked its own answer after the clock: a union-find pass over the
  returned edges, and the count against n minus the number of connected
  components of the whole graph.

THE CLOCK

  The difference between two readings of the CPU clock, taken immediately
  before the solver call and immediately on return.  For the five native
  processes it is getrusage(RUSAGE_SELF), user plus system; for the two JVM
  solvers it is the solver thread's CPU time (ThreadMXBean) plus the
  collector's accumulated time (GarbageCollectorMXBean.getCollectionTime), with
  the serial collector and one processor.  The Go clock counts every thread of
  the process, so Go's own collector is in it too.

  The export, in all three languages: the whole verified program
  (kruskal_imp_min negates and copies the costs, sorts the edge index array
  with its own quicksort, initialises its union-find array and runs the loop).
  Its three input arrays are built outside and recorded in the campaign
  directory, fresh for every repeat because the export sorts the index array
  in place.

  The libraries: a structure that can be filled while the file is read may be
  built outside the clock; one that needs the complete arc list first is built
  after parsing, inside the clock.  Kruskal's algorithm needs no adjacency
  structure, so each library was given the representation most suitable for
  reading its edges off:
    lemon     SmartGraph + EdgeMap<int64_t>, filled edge by edge.  OUTSIDE.
              Inside: kruskal(g, cost, tree) with a fresh EdgeMap<bool>, which
              collects the edges into a vector, std::sorts it by cost and runs
              UnionFind.
    jgrapht   DefaultUndirectedWeightedGraph<Integer, DefaultWeightedEdge>,
              filled edge by edge.  OUTSIDE.  Inside: KruskalMinimumSpanningTree
              copies edgeSet() to a list, sorts it and runs UnionFind.
    scipy     csr_matrix((data, indices, indptr)) from the (lo, hi)-sorted
              edges, a bincount and a cumulative sum.  INSIDE, rebuilt every
              repeat, then minimum_spanning_tree (Kruskal, Cython).
    networkx  Graph, filled edge by edge.  OUTSIDE.  Inside:
              minimum_spanning_edges(algorithm='kruskal'), drained.

  Both JVM drivers warm the JIT on the instance itself before the clock opens
  (on its induced subgraph above 2^14 edges for scala, 2^18 for jgrapht),
  spinning rather than sleeping between rounds, and call System.gc() before
  each clocked repeat, outside the clock.  Every run started on a warm core:
  the runner spun three seconds on the run's core and then exec'd the driver
  on it, outside the driver's process and outside every clock it reads (tag
  warmcore=3s); an idle core on the measurement machine is parked at 1.5 GHz.

THE SCALA AND GO BUILDS OF THE EXPORT ARE QUADRATIC

  kruskal_imp_min turns the cost array into a list and back (freeze, then
  of_list).  In the Scala and Go targets of_list indexes the cons list once per
  element, so that step is quadratic in the edge count; the SML build's of_list
  is Array.fromList and is linear.  The two ladders stop where that step passes
  the cap.  That is a property of the export as generated and nothing was
  changed: the whole generated program is what is measured.

ONE PROBLEM PER PROCESS

  Each instance and each repeat was its own process:

    taskset -c <core> timeout -k 10 1200 \
        python warm_then_exec.py 3 -- \
        <driver> --tag "<family>;rep=<k>;warmcore=3s" <instance.gr>

  Seven workers, one per L3 cache island, on cores 4, 8, 12, 16, 20, 24 and 28;
  cores 0-3 were reserved.  The Python drivers ran with --mem-gb 45 (an
  RLIMIT_AS of 45 GiB), the JVMs with -Xmx45g, the SML, Go and C++ processes
  uncapped.  The solvers were measured in groups, a group finishing every
  family, size and repeat before the next began: sml first, then the four
  libraries, then scala and go.

THE GRID

  Square-n     n = 1024 .. 2096704, twelve sizes, ten instances each
  Long-n       n = 1024 .. 2097152, twelve sizes, ten instances each
  Dense-n      n = 1024 .. 32768, six sizes, ten instances each
  three repeats of every problem; 300 problems, 6300 runs.  The same files as
  the BFS and DFS studies: Square-n and Long-n from the challenge's spgrid
  through its genSquare-n.gr.pl and genLong-n.gr.pl scripts changed only to
  make ten graphs per size, Dense-n from the challenge's sprand at m = n^2/16.

THE SEVEN COLUMNS

  ours, one verified export compiled to three languages:
    sml        Standard ML; MLton 20241230, -inline 10000; getrusage clock
    scala      Scala 3.3.8 on JDK 21.0.12.1, -Xmx45g, one processor, serial collector, 24 GiB solve-thread stack; clock = thread CPU + collector time; warmed up on the instance itself
    go         Go 1.27.2, goroutine stack limit raised to 2000 MB; getrusage clock
  libraries:
    lemon      LEMON 1.3.1 kruskal(g, cost, tree) on SmartGraph + EdgeMap<int64_t>, filled OUTSIDE the clock; g++ 11.4.0 -O3 -march=native -DNDEBUG
    jgrapht    JGraphT 1.5.3 KruskalMinimumSpanningTree on DefaultUndirectedWeightedGraph, filled OUTSIDE the clock; JDK 21.0.12.1, -Xmx45g, one processor, serial collector; clock = thread CPU + collector time; warmed up on the instance itself
    scipy      scipy 1.15.3 sparse.csgraph.minimum_spanning_tree on a csr_matrix built INSIDE the clock, rebuilt every repeat; weights shifted up by one before the clock
    networkx   networkx 3.4.2 minimum_spanning_edges(algorithm='kruskal'), drained, on a Graph filled OUTSIDE the clock

  Checksums of the export and the libraries as measured:
    7fe620ba321c4bba8e6d7bae5dad15c6  Kruskal_SML/Kruskal_Imperative_Min.SML
    d4edb346d6c44680e753c0e62af44367  Kruskal_Scala/Kruskal_Imperative_Min.scala
    25934c326f28f9f556297f235805073d  Kruskal_Go/Kruskal_Imp_Min/exported.go
    f73efc783603c57d8e8e53c90af21e88  jgrapht-core-1.5.3.jar
    53dfa9f277efd1d392148eb607d9b4a6  jheaps-0.14.jar
    7173df3f675c6860fb24ba5b5b65fefa  libemon.a (LEMON 1.3.1, CMake Release build)
    4483d259166cd13d9a7b4fa74b8c1ce6  scala3-library_3-3.3.8.jar
    4825bad81cee169fed825dc2f98a7d41  scala-library-2.13.18.jar

WHERE THE ROWS COME FROM

    results/20261015_091344   all seven columns
