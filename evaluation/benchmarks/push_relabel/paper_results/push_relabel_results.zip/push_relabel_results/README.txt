Push-relabel study -- the published tables and raw rows (Tables 19 to 21)
=========================================================================

One directory per column, one CSV per family:

    <column>/rmf-long.csv, wash-rlg-long.csv, ak.csv
    <column>/conditions.txt    machine, pinning and clock, as the campaign
                               recorded them
    <column>/raw/<family>.csv  the driver rows the tables were built from
    COLUMNS.txt                which column comes from which results directory

CSV SHAPE

    rung,nodes,arcs,s1,s2,s3,finished,average_ms      rmf-long, wash-rlg-long
    rung,nodes,arcs,r1,r2,r3,finished,median_ms       ak

  One row per rung of the ladder.  For the two seeded families s1..s3 are three
  different graphs of that size, built with seeds 1, 2 and 3, and the last
  column is their mean; ak takes no seed, so r1..r3 are three repeats of the
  one instance and the last column is their median.  Times are milliseconds of
  CPU; finished says how many of the three produced one.

  A cell that is not a number:
    TIMEOUT         did not finish inside the 1200 s cap
    MEMORY, STACK   ran out of address space, or of stack
    ERROR           the solver failed on its own terms (only sml_afp: its dense
                    n-by-n residual array overflows a 32-bit index from
                    n = 65,538, "unhandled exception: Overflow")
    NOT_APPLICABLE  the instance is outside the solver's preconditions: the AFP
                    export's network model forbids antiparallel arcs and genrmf
                    joins neighbours both ways, so the whole rmf-long ladder is
                    outside it
    NOT_ATTEMPTED   not run, because the same solver had already failed lower
                    down the same ladder
  The stopping rule is per solver and per family.

THE CLOCK

  CPU time of the whole process, user plus system, read immediately before the
  solver call and immediately on return; every driver read the clock twice, so
  cpu_ms is the one time per run.

  The three verified exports: the whole generated program; the entry point is
  handed plain arc arrays and builds every structure it uses (the residual
  graph, the level buckets, the current-arc pointers) inside the call.

  The reference solvers: a structure that can be filled arc by arc while the
  file is read may be built outside the clock; one that needs the complete
  arc list is built after parsing, inside the clock.  Two libraries are
  measured both ways:

    lemon_csr   INSIDE.  LEMON's StaticDigraph, its own CSR, whose build()
                takes a complete arc list sorted by tail.  The clock covers the
                counting sort by tail, the build, the capacity map laid over
                the new arc ids, Preflow's own setup and the solve, rebuilt on
                every repeat.
    lemon_linked
                OUTSIDE.  LEMON on SmartDigraph, a linked arc list filled as
                the file is read; the clock covers Preflow's setup and the solve.
    scipy_csr   INSIDE.  csgraph takes a CSR matrix; coo_matrix(...).tocsr() is
                a separate sort-and-pack pass over the complete arc arrays.  The
                clock covers that build and the Dinic call, rebuilt on every
                repeat.
    scipy_prebuilt
                OUTSIDE.  The same matrix built once before the clock opened;
                the clock covers the Dinic call.
    jgrapht     INSIDE BY CONSTRUCTION.  The pseudograph JGraphT is handed fills
                as the file is read and sits outside; PushRelabelMFImpl then
                copies it into its own arrays inside the measured call.
    hipr        hi_pr's parser writes its node and arc arrays as it reads the
                file, so the build is the parse.  Its bucket and queue
                allocation (allocDS) and init() are inside the clock.
    networkx    the dict-of-dicts graph fills as the file is read and sits
                outside.

  Repacking the parsed arrays into the list a library's constructor takes is
  marshalling and stays outside in every column.  For JGraphT the figure is
  read from /proc/self/stat and not from ThreadMXBean: HotSpot's serial
  collector runs on the VM thread, so a per-thread clock drops every
  collection (on one run of ak-4102 the thread clock showed 7.2 s where the
  process had burned 21.6).

  The short ak rungs of lemon_csr (ak-4102 to ak-131078) and of scipy_csr
  (ak-4102 to ak-16390) were measured with a 5 s busy spin on the target core
  before each launch (a separate process, outside the driver and its clock),
  three repeats each; those rows carry warmcore=5s in their tag.  No other row
  of this study was measured with a warm-up spin.

ONE PROBLEM PER PROCESS

  Every instance got its own process, with its own source and target on the
  command line; repeats got their own processes too.  Runs were pinned one per
  L3 cache island, seven at a time, with cores 0-3 kept free of measurement
  work.  All eight solvers compute a maximum flow, not merely a maximum
  preflow; summing the flow value is outside the measured region.

THE GRID

  rmf-long       15 rungs, n = 4,096 .. 67,109,224, genrmf -c1 1 -c2 10000
  wash-rlg-long  15 rungs, n = 4,098 .. 67,108,866, washington 2 128 D2 10000
  ak              9 rungs, n = 4,102 .. 1,048,582, ak K
  three runs of every rung.  The ladders start below the Flow Challenge 2.0
  prescription and climb into it: each long family gets nine rungs below the
  six prescribed ones, built by the challenge's own rule run downward; ak is
  extended three rungs above the 1994 table.  The generators are deterministic
  given their arguments, so the arguments in the rung name are the instance.

  rmf-long is Goldberg's genrmf: b square frames of a-by-a nodes, consecutive
  frames joined by a random matching, a long thin pipe.  wash-rlg-long is the
  Washington generator's random level graph, 128 nodes per level and D2 levels,
  close to a layered network.  ak is Cherkassky and Goldberg's adversarial
  family, built so that push-relabel performs about n^2 pushes and relabels
  regardless of heuristics; it takes one argument and no seed.

DO THE COLUMNS AGREE ON THE ANSWER?

  Of the 96 instances that at least one solver finished, 75 were finished by
  two or more solvers, and on every one of them all the solvers that finished
  report the same maximum flow value.  Twenty-one instances have exactly one
  solver that finished, always hi_pr: the three seeds each of rmf-long-54-2896,
  -64-4096, -76-5793, and of wash-rlg-long-128-65536, -131072, -262144 and
  -524288.  rmf-long-91-8104 (67,109,224 nodes) has no answer from anybody.

THE EIGHT SOLVERS, AND WHICH HEURISTICS EACH HAS

  The four that matter for push-relabel are the selection rule, the gap
  heuristic, periodic global relabelling, and exact starting labels from one
  reverse breadth-first sweep.

    hipr       all four.  Goldberg's hi_pr 3.5, C, -O3 -march=native
    networkx   all four, in pure Python
    jgrapht    FIFO, gap, global relabelling, exact initial labels; Java 21
    lemon      highest label, gap (bound decrease), exact initial labels; no
               periodic global relabelling.  Two columns: lemon_csr on
               StaticDigraph built inside the clock, lemon_linked on
               SmartDigraph built outside; C++ -O3 -march=native
    sml_hl     highest label and gap only: our export, MLton -inline 10000
    sml_fifo   FIFO and gap only: the same export, other selection rule
    sml_afp    none of the four.  The older AFP export, plain FIFO
    scipy      not push-relabel: scipy.sparse.csgraph.maximum_flow is Dinic.
               Two columns: scipy_csr with the CSR build inside the clock and
               scipy_prebuilt with it outside

  hi_pr is Goldberg's 3.5 distribution with one character changed, in its
  input parser, which could not read its own sample problem line when built by
  a current compiler; hi_pr.c itself is unchanged.  Scala and Go builds of both
  exports exist and are not measured: on ak-4102 the same export took 68 ms in
  Standard ML, 10.2 s in Scala and 643.6 s in Go, so every cell of those
  columns would be a timeout.

  LEMON's wash-rlg-long times vary enormously between seeds at the same size
  (at wash-rlg-long-128-4096 the three seeds took 7.6 s, 6.2 s and 257 s on
  the CSR), so single-seed figures from that family should not be read closely.

  Compiler flags: LEMON g++ -O3 -march=native -DNDEBUG; hi_pr gcc -O3
  -march=native -DNDEBUG -DEXCESS_TYPE_LONG; the generators gcc -O2; the three
  SML exports MLton -inline 10000; JGraphT javac on Java 21; SciPy 1.15.3 and
  NetworkX 3.4.2.

THE COLUMN NAMES

    sml_hl          new export, highest label, Standard ML (MLton, -inline 10000)
    sml_fifo        new export, FIFO, Standard ML (MLton, -inline 10000)
    lemon_csr       LEMON 1.3.1 Preflow (highest label) on StaticDigraph, its CSR, built INSIDE the clock, rebuilt every repeat; C++ -O3 -march=native
    lemon_linked    LEMON 1.3.1 Preflow (highest label) on SmartDigraph, a linked arc list, built OUTSIDE the clock; C++ -O3 -march=native
    hipr            Goldberg hi_pr 3.5 (highest label, gap, global relabelling), C -O3 -march=native
    sml_afp         AFP export, FIFO, Standard ML (MLton, -inline 10000)
    networkx        NetworkX preflow_push, pure Python
    scipy_csr       SciPy 1.15.3 maximum_flow, Dinic, on a CSR matrix built INSIDE the clock, rebuilt every repeat
    scipy_prebuilt  SciPy 1.15.3 maximum_flow, Dinic, on the same CSR matrix built BEFORE the clock opened, once per process
    jgrapht         JGraphT PushRelabelMFImpl, Java 21

WHERE EACH COLUMN'S ROWS COME FROM

    sml_hl          results/20261012_133154/sml_hl.csv
    sml_fifo        results/20261012_133154/sml_fifo.csv
    lemon_csr       results/20261014_174311/lemon.csv; rows of ak-4102 .. ak-131078 from results/20261015_warm_ak/lemon.csv (warmcore=5s)
    lemon_linked    results/20261012_133154/lemon.csv
    hipr            results/20261012_133154/hipr.csv
    sml_afp         results/20261012_133154/sml_afp.csv
    networkx        results/20261012_133154/networkx.csv
    scipy_csr       results/20261014_174311/scipy.csv; rows of ak-4102 .. ak-16390 from results/20261015_warm_ak/scipy.csv (warmcore=5s)
    scipy_prebuilt  results/20261012_133154/scipy.csv
    jgrapht         results/20261012_133154/jgrapht.csv
  The 20261012_133154 files carry no NOT_ATTEMPTED rows (the tables derive the
  word from the missing row); the 20261014_174311 scipy rows carry them.
