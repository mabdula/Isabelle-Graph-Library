Push-relabel study -- headline timings
======================================

Ten columns on three maximum-flow families from the DIMACS Flow Challenge
generators: eight solvers, of which two libraries appear twice, once on the
structure the first campaign gave them and once on CSR built inside the
clock.  One directory per column, one CSV per family:

    <column>/rmf-long.csv
    <column>/wash-rlg-long.csv
    <column>/ak.csv
    <column>/conditions.txt    machine, pinning and clock, exactly as the
                               campaign recorded them
    <column>/raw/              the unaggregated driver rows these tables
                               were built from
    COLUMNS.txt                which column comes from which directory

CSV SHAPE

    rung,nodes,arcs,s1,s2,s3,finished,average_ms      rmf-long, wash-rlg-long
    rung,nodes,arcs,r1,r2,r3,finished,median_ms       ak

  One row per rung of the ladder.  A column is one measured run.

  The Flow Challenge prescribes different seeds for the same size, so for the
  two seeded families s1..s3 are three DIFFERENT GRAPHS of that size, built
  with seeds 1, 2 and 3 -- three problems, not three repeats, and the last
  column is their mean.  ak takes no seed and is fully determined by its one
  argument, so there r1..r3 are three repeats of the one instance and the last
  column is their median.  Median within a problem, mean across problems: the
  convention used throughout this study and the two before it.

  Times are milliseconds of CPU.  finished says how many of the three produced
  one, so two rows are comparable only when both say finished = 3.

  A cell that is not a number is one of:

    TIMEOUT         did not finish inside the 1200 s cap
    MEMORY, STACK   ran out of address space, or of stack
    ERROR           the solver failed on its own terms; see the note beside
                    the only column that does this, sml_afp
    NOT_APPLICABLE  the instance is outside the solver's preconditions, so it
                    was not run.  The AFP export's network model forbids
                    antiparallel arcs -- it keeps one residual capacity per
                    ordered pair -- and genrmf joins neighbours both ways, so
                    the whole rmf-long ladder is outside it.  That is a
                    structural mismatch, not a failure, and recording it as a
                    timeout or a wrong answer would misrepresent it.
    NOT_ATTEMPTED   not run, because the same solver had already failed lower
                    down the same ladder.  A solver that cannot do n is not
                    going to do 2n, and the machine time is better spent
                    elsewhere.  Once one run of a rung times out, the rest of
                    that rung and every rung above it carry this word.

  The stopping rule is per solver and per family: one column giving up on
  rmf-long says nothing about its ak ladder, and the ladders were climbed
  independently.

THE CLOCK

  CPU time of the whole process, user plus system, read immediately before the
  solver call and immediately on return, with nothing else between the
  readings.  Every driver read the clock twice, so cpu_ms is the one time
  per run and there is no build/solve split in this study.

  For THE THREE VERIFIED EXPORTS the whole generated program is measured.  The
  entry point is handed plain arc arrays and builds every structure it uses --
  the residual graph, the level buckets, the current-arc pointers -- inside the
  call, so that setup is inside the clock.  That is the point of the study: a
  benchmark of generated code has to cover the whole generated program.

  For THE REFERENCE SOLVERS the rule since 2026-10-14 is this: a structure
  that can be filled arc by arc while the file is read may be built outside
  the clock; a structure that needs the complete arc list first is built
  after parsing, and that build is the first part of the clocked period,
  exactly as it is for the exports' own CSR.  The two libraries measured both
  ways are here both ways.

    lemon_csr   INSIDE.  LEMON is given StaticDigraph, its own CSR, whose
                build() takes a complete arc list sorted by tail and so cannot
                be filled while the file is read.  The clock opens on the
                parsed arc list and covers the counting sort by tail, the
                build, the capacity map laid over the new arc ids, Preflow's
                own setup and the solve, rebuilt on every repeat.  Measured
                2026-10-14.
    lemon_linked
                OUTSIDE.  The first campaign had LEMON on SmartDigraph, a
                linked arc list filled arc by arc as the file is read; the
                clock covers Preflow's setup and the solve on it.  Measured
                2026-10-12.
    scipy_csr   INSIDE.  csgraph takes nothing but a CSR matrix, and
                coo_matrix(...).tocsr() is the same separate sort-and-pack pass
                over the complete arc arrays.  The clock covers that build and
                the Dinic call, rebuilt on every repeat.  Measured 2026-10-14.
    scipy_prebuilt
                OUTSIDE.  The first campaign built the same matrix once,
                before the clock opened; the clock covers the Dinic call.
                Measured 2026-10-12.
    jgrapht     INSIDE BY CONSTRUCTION.  The pseudograph JGraphT is handed fills
                arc by arc as the file is read and sits outside; PushRelabelMFImpl
                then copies it into its own arrays inside the measured call.
                Measured 2026-10-12.
    hipr        hi_pr's parser writes its node and arc arrays as it reads the
                file, so the build is the parse.  Its bucket and queue
                allocation (allocDS) and init() are inside the clock.
    networkx    the dict-of-dicts graph fills arc by arc as the file is read
                and sits outside.

  Repacking the parsed arrays into the list a library's constructor takes is
  marshalling into its input format, not the building of its structure, and
  stays outside in every column.  What each column spends outside the clock
  is recorded in the campaign directories (parse, dedup and build times per
  row) and tabulated in findings_core/overhead.csv; it is not in this zip.

  For JGraphT the figure is read from /proc/self/stat and not from Java's
  ThreadMXBean.  HotSpot's serial collector runs on the VM thread, so a
  per-thread clock drops every collection: on one run of ak-4102 the thread
  clock showed 7.2 s where the process had burned 21.6.  The per-thread
  figure is kept in the campaign directory, not here.

  Wall time was recorded in the campaign directories but nothing here is
  derived from it and it is not in this zip: seven runs shared the machine,
  so wall time carries what the other six were doing and CPU time does not.

THE DATA STRUCTURES, COLUMN BY COLUMN

    sml_hl, sml_fifo
                the new export: a CSR residual graph (offsets and packed
                arcs with reverse-arc indices), level buckets, current-arc
                pointers, built by the exported code from the parser's arc
                arrays.  INSIDE the clock.
    sml_afp     the AFP export: a dense n-by-n residual capacity array, one
                entry per ordered pair, and a FIFO queue, built by the
                exported code.  INSIDE.  (The dense array is why the column
                says ERROR from n = 65,538 upward: its index into the array
                exceeds a 32-bit signed integer there, and the run ends with
                "unhandled exception: Overflow"; and why rmf-long is
                NOT_APPLICABLE.)
    lemon_csr   LEMON's StaticDigraph: CSR, arcs sorted by tail, from a
                complete tail-sorted arc list, plus a capacity ArcMap over
                the new arc ids.  INSIDE, rebuilt every repeat.
    lemon_linked
                LEMON's SmartDigraph: a linked arc list, every arc an entry
                with next-out and next-in pointers, arcs in file order, plus
                its capacity ArcMap, filled arc by arc as the file is read.
                OUTSIDE.
    hipr        hi_pr's own node and arc arrays, written by its parser as
                it reads (the build is the parse); buckets and queue
                allocated inside the clock.
    networkx    NetworkX's DiGraph, a dict of dicts with the capacity as an
                attribute, filled arc by arc as the file is read.  OUTSIDE.
    scipy_csr   SciPy's csr_matrix of capacities, built by coo_matrix((cap,
                (tails, heads))).tocsr(), a sort-and-pack pass over the
                complete arc arrays.  INSIDE, rebuilt every repeat.
    scipy_prebuilt
                the same csr_matrix, built once by the same call before the
                clock opened.  OUTSIDE.
    jgrapht     jgrapht-core's DirectedWeightedPseudograph (an object per
                arc, hash maps around it), filled arc by arc as the file is
                read, OUTSIDE; PushRelabelMFImpl copies it into its own
                arrays INSIDE the measured call.

ONE PROBLEM PER PROCESS

  Every instance got its own process, with its own source and target on the
  command line; no driver accepts a list of problems.  Repeats got their own
  processes too, so no measurement was taken on a cache an earlier measurement
  had warmed.

  The source and the target are fixed per instance and are the same for every
  solver, so all columns answer exactly the same question on exactly the same
  graph.  Both are copied into each result row beside the time they produced.

  Runs were pinned one per L3 cache island, seven at a time, so no two
  concurrent runs shared any level of cache.  Cores 0-3 were kept free of
  measurement work.

  All eight solvers compute a MAXIMUM FLOW, not merely a maximum preflow.
  Summing the flow value is outside the measured region for all of them; the
  sums were taken only to cross-check the answers against each other.

THE GRID

  rmf-long       15 rungs, n = 4,096 .. 67,109,224, genrmf -c1 1 -c2 10000
  wash-rlg-long  15 rungs, n = 4,098 .. 67,108,866, washington 2 128 D2 10000
  ak              9 rungs, n = 4,102 .. 1,048,582, ak K
  three runs of every rung

  The ladders start well below the Flow Challenge 2.0 prescription and climb
  into it.  The challenge's smallest rmf-long rung, n = 2,090,912
  (rmf-long-38-1448), is near the top of what most columns can do: hi_pr takes
  about 7 s there (6.6 s, mean of the three seeds), LEMON on its CSR 267 s,
  JGraphT 200 s, and every other column times out there or below, so a ladder
  that began there would say nothing about the exports.  (The first campaign's
  linked-list LEMON timed out one rung lower, at rmf-long-32-1022, and never
  reached it.)  Each long family therefore gets nine rungs below the
  prescribed ones, built by the challenge's own rule run downward, with the
  six prescribed rungs sitting on top of them unchanged.  Those smaller sizes
  are the ones comparable to the BFS and the Dijkstra study.  ak is extended
  the other way: the 1994 table stops at K = 16384 because a 40 MHz SPARC took
  nine minutes there, and three larger rungs are added above it.

  Instances were generated one at a time and deleted as soon as every solver
  had finished with them -- one pass over both long ladders is some 32 GB and
  the box has about 104 GB free.  Nothing is lost by that: all three
  generators are deterministic given their arguments, so the arguments in the
  rung name ARE the instance and any row can be reproduced by running the
  generator again.

THE THREE FAMILIES, AND WHAT THEY ASK OF THE ALGORITHM

  rmf-long is Goldberg's genrmf: b square frames of a-by-a nodes, each frame a
  grid, consecutive frames joined by a random matching, capacities inside a
  frame large and capacities between frames drawn from [1, 10000].  Long means
  b is much larger than a -- a chain of many small frames -- so the flow has
  to be pushed down a long thin pipe and distance labels climb high.  It is
  the family the max-flow literature treats as the general-purpose hard case,
  and the one where the field here thins fastest: above 4.1M nodes hi_pr is the
  only column still answering, and it goes on alone for three more rungs.

  wash-rlg-long is the Washington generator's random level graph, 128 nodes
  per level and D2 levels, each node joined to three random nodes on the next
  level with capacities in [1, 10000].  Long means many thin levels.  The
  structure is close to a layered network, which is exactly what Dinic-style
  blocking-flow methods are built for, and it is the family where SciPy -- the
  one column here that is not push-relabel at all -- does best relative to the
  rest.

  ak is Cherkassky and Goldberg's adversarial family, and it is the reason the
  study has three families rather than two.  It is built so that push-relabel
  performs about n^2 pushes and relabels REGARDLESS OF HEURISTICS: global
  relabelling, the gap heuristic and exact initial labels all buy nothing on
  it.  hi_pr, which has all of them, goes quadratic here like everything else
  -- its time multiplies by about four at every doubling.  There is no
  randomness in the family at all; the generator takes one argument and no
  seed.

WHAT THE SHAPE OF THE DATA SAYS

  Against hi_pr, taken as 1.0, the verified SML export costs (the ratio of the
  two columns' table cells -- the median over repeats on ak, the mean over the
  three seeds on the other two -- at the smallest rung and at the largest rung
  both columns finished):

        family           smallest rung       largest rung both finished
        ak                       5.2x                    4.6x
        wash-rlg-long            5.8x                  399.7x
        rmf-long                14.9x                  316.8x

  Those are sml_fifo.  On ak its ratio never leaves the band 3.6x to 5.2x over
  eight rungs; on the other two families it climbs by a factor of about seventy
  and about twenty-one.  sml_hl behaves the same way, in a band of 4.9x to 8.7x
  on ak against 6.1x to 365.4x on wash-rlg-long.

  A CONSTANT factor is a language-and-codegen cost.  A GROWING factor is a
  different amount of work.  On ak, where the instance pins the operation count
  equal for everyone and hi_pr's three heuristics buy it nothing, the
  comparison collapses to cost per elementary operation, and there the export
  sits at a flat 4.5x or so -- about what MLton against gcc -O4, plus the bounds
  discipline that verification brings, should cost.  On the other two families
  the factor climbs with size, which is what a missing heuristic looks like:
  hi_pr is not executing the same operations faster, it is executing far fewer
  of them.

  This is read off the shape of the ratios and not off instrumented push and
  relabel counts, which the drivers do not record.  Counting them would settle
  it properly and would be cheap to add.

  Two results worth reading before the headline ones.  LEMON on its CSR beats
  hi_pr by five to ten times on ak, the family where neither can be helped by
  heuristics.  And sml_fifo beats sml_hl on ak at every size, which is the
  opposite of the usual ordering and again points at ak defeating the
  highest-label rule rather than at anything in the code.

DO THE COLUMNS AGREE ON THE ANSWER?

  A study whose columns disagree about the flow value has no business comparing
  their speeds.  Of the 96 instances that at least one solver finished (each
  seed of a seeded rung is its own instance; ak has one per rung), 75 were
  finished by two or more solvers, and on every one of them all the solvers
  that finished report the same maximum flow value.  No disagreements, and
  none between the two measurements of LEMON or of SciPy and the rest.  The
  per-instance table is findings_core/agreement.csv.

  Twenty-one instances have exactly one solver that finished, always hi_pr,
  so their flow values are unverified: the three seeds each of rmf-long-54-2896,
  rmf-long-64-4096, rmf-long-76-5793, and of wash-rlg-long-128-65536, -131072,
  -262144 and -524288.

  One rung has no answer from anybody: rmf-long-91-8104, at 67,109,224 nodes.
  hi_pr timed out on the first seed, which stopped its ladder, and it was the
  last column still climbing.  It is the one point in the campaign that is
  blank across the board.

THE EIGHT SOLVERS, AND WHICH HEURISTICS EACH HAS

  The four that matter for push-relabel are the selection rule, the gap
  heuristic, periodic global relabelling, and exact starting labels from one
  reverse breadth-first sweep.

    hipr       all four.  Goldberg's hi_pr 3.5, C, -O3 -march=native
    networkx   all four, in pure Python
    jgrapht    FIFO, gap, global relabelling, exact initial labels; Java 21
    lemon      highest label, gap (it calls it bound decrease), exact initial
               labels; no periodic global relabelling, and no setting to ask
               for one.  Two columns: lemon_csr on StaticDigraph, LEMON's
               CSR, built inside the clock, and lemon_linked on SmartDigraph,
               a linked arc list, built outside; C++ -O3 -march=native
    sml_hl     highest label and gap only -- our export, MLton -inline 10000
    sml_fifo   FIFO and gap only -- the same export, other selection rule
    sml_afp    none of the four.  The older AFP export, plain FIFO
    scipy      not push-relabel at all: scipy.sparse.csgraph.maximum_flow is
               Dinic.  It is here because it is what a SciPy user gets.  Two
               columns: scipy_csr with the CSR build inside the clock and
               scipy_prebuilt with it outside

  hi_pr is Goldberg's 3.5 distribution with ONE CHARACTER changed, in its input
  parser, which could not read its own sample problem line when built by a
  compiler of this decade.  hi_pr.c itself is unchanged -- init, globalUpdate,
  gap, relabel, discharge, stageOne, stageTwo and the constants ALPHA, BETA and
  GLOB_UPDT_FREQ are all compiled from Goldberg's bytes.  See
  drivers/c/hipr-3.5/PATCHES-FOR-THIS-STUDY in the study directory.

  Scala and Go builds of both exports exist and work and are deliberately not
  measured.  On ak-4102, the smallest instance in the study, the same export
  took 68 ms in Standard ML, 10.2 s in Scala and 643.6 s in Go.  At the sizes
  this campaign runs, every one of those cells would be a timeout, and a column
  of timeouts is not a measurement.

  There is also a relabel-to-front variant of the newer export.  It is not
  benchmarked: relabel-to-front is usually slow and would add a column that
  says so.

ONE CAVEAT ON LEMON

  Its wash-rlg-long times vary enormously between seeds at the same size --
  at wash-rlg-long-128-4096 the three seeds took 7.6 s, 6.2 s and 257 s on
  the CSR (8.2, 6.0 and 264 s on the linked list), a factor of forty -- far
  more than any other column, so single-seed figures from that family should
  not be read closely.  Its topmost finished rung there is a single seed: the
  other two of that rung timed out or were not attempted.

THE CAMPAIGN OF 2026-10-14: lemon_csr AND scipy_csr

  The first campaign (results/20261012_133154, 2026-10-12) measured LEMON on
  a linked arc list built outside the clock and SciPy with its CSR build
  outside the clock; those are the columns lemon_linked and scipy_prebuilt.
  Both libraries were measured on 2026-10-14 (results/20261014_174311)
  with the structure build inside the clock, as THE CLOCK above says; those
  are lemon_csr and scipy_csr.  The six other columns are the 2026-10-12 rows.  The effect is large where the layout
  mattered: lemon_csr on rmf-long is 3.9 to 13 times faster than
  lemon_linked from n = 65,536 upward and finishes three more rungs, among
  them the challenge's smallest two; on ak and wash-rlg-long the change is
  small and goes both ways; scipy_csr is within a few percent of
  scipy_prebuilt everywhere but on the short ak rungs, which were measured
  with a warm-up spin (next paragraph).

  The short ak rungs of lemon_csr (ak-4102 to ak-131078) and of scipy_csr
  (ak-4102 to ak-16390) were measured with a 5 s busy spin on the target
  core before each launch (bench/run_campaign.py --warm-core 5; the spin is
  a separate process, outside the driver and its clock), three repeats each,
  in results/20261015_warm_ak; those rows carry warmcore=5s in their tag.
  From LEMON ak-262150 and SciPy ak-32774 upward the rows are the
  2026-10-14 campaign's.  No other column of this study was measured with a
  warm-up spin.

  One more difference in the files.  The 2026-10-12 files carry no
  NOT_ATTEMPTED rows (the tables derive the word from the missing row); the
  2026-10-14 scipy rows carry them (ak-1048582).  The tables read the same
  either way.

  The 2026-10-14 campaign's conditions.txt says "runs at once 7, one to
  each L3 island"; with two solvers in the campaign at most three runs were
  in flight (the three ak repeats), one per island.  The first campaign ran
  in two segments, the second from 13:50 on 2026-10-12 with hi_pr added to
  the solver list; hi_pr's rows for the rungs below that point were measured
  one at a time in the second segment.  campaign.log records both segments.

  Compiler flags (bench/build_all.sh): LEMON g++ -O3 -march=native -DNDEBUG;
  hi_pr gcc -O3 -march=native -DNDEBUG -DEXCESS_TYPE_LONG; the generators
  gcc -O2; the three SML exports MLton -inline 10000; JGraphT javac on
  Java 21; SciPy 1.15.3 and NetworkX 3.4.2 from the study's own .venv.

THE COLUMN NAMES, in the order the campaign ran them

    sml_hl          new export, highest label, Standard ML (MLton, -inline 10000)
    sml_fifo        new export, FIFO, Standard ML (MLton, -inline 10000)
    lemon_csr       LEMON 1.3.1 Preflow (highest label) on StaticDigraph, its CSR, built INSIDE the clock, rebuilt every repeat; C++ -O3 -march=native; 2026-10-14
    lemon_linked    LEMON 1.3.1 Preflow (highest label) on SmartDigraph, a linked arc list, built OUTSIDE the clock; C++ -O3 -march=native; 2026-10-12
    hipr            Goldberg hi_pr 3.5 (highest label, gap, global relabelling), C -O3 -march=native
    sml_afp         AFP export, FIFO, Standard ML (MLton, -inline 10000)
    networkx        NetworkX preflow_push, pure Python
    scipy_csr       SciPy 1.15.3 maximum_flow, Dinic (SciPy has no push-relabel), on a CSR matrix built INSIDE the clock by coo_matrix(...).tocsr(), rebuilt every repeat; 2026-10-14
    scipy_prebuilt  SciPy 1.15.3 maximum_flow, Dinic, on the same CSR matrix built BEFORE the clock opened, once per process; 2026-10-12
    jgrapht         JGraphT PushRelabelMFImpl, Java 21

WHERE EACH COLUMN'S ROWS COME FROM

    sml_hl          results/20261012_133154/sml_hl.csv
    sml_fifo        results/20261012_133154/sml_fifo.csv
    lemon_csr       results/20261014_174311/lemon.csv
    lemon_linked    results/20261012_133154/lemon.csv
    hipr            results/20261012_133154/hipr.csv
    sml_afp         results/20261012_133154/sml_afp.csv
    networkx        results/20261012_133154/networkx.csv
    scipy_csr       results/20261014_174311/scipy.csv
    scipy_prebuilt  results/20261012_133154/scipy.csv
    jgrapht         results/20261012_133154/jgrapht.csv
    lemon_csr       rows of ak-4102 .. ak-131078 from results/20261015_warm_ak/lemon.csv (measured with a 5 s warm-up spin, tag warmcore=5s), the other rows from results/20261014_174311/lemon.csv
    scipy_csr       rows of ak-4102 .. ak-16390 from results/20261015_warm_ak/scipy.csv (measured with a 5 s warm-up spin, tag warmcore=5s), the other rows from results/20261014_174311/scipy.csv

Built 2026-10-15 01:13 by bench/build_results_zip.py.
results/ holds the raw data; this holds the tables and, under
raw/, the driver rows cut down to the one measured time.
